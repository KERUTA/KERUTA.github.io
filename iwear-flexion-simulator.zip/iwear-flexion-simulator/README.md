# Iwear Flexion シミュレーター

自作の三点曲げ試験装置 **Iwear Flexion** を、ブラウザの上で本物と同じように動かせるシミュレーターです。
左に装置の 3D モデル、右に試験プログラム（`iwearflexion_4.py`）と同じ操作画面が出ます。
装置を持っていけない場所で、使い方や仕組みを説明するために作りました。

![画面](docs/screenshot.png)

## 使い方

公開ページ（GitHub Pages）を開くだけで動きます。インストールは要りません。

- 3D：ドラッグで回転、ホイール（2本指）で拡大縮小、右ドラッグで移動。部品をクリックすると説明が出ます。
- 「部品（半透明）」：部品ごとに 表示／半透明／非表示 を切り替え。「中を透かして見る」で台の中のモーターが見えます。
- 「見るだけモード」：プログラム画面を閉じて 3D だけを大きく表示します。
- 「速さ」：×1 が本物と同じ速さ。試験（2 mm/分）は時間がかかるので、説明のときは ×10 が便利です。
- キー操作は本物と同じ：Enter＝START、0＝0mm homing、Esc＝EMG STOP、↑↓＝手動移動

### 試験の流れ（本物と同じ）

1. 曲げ治具を外した状態で、UP（↑）・DOWN（↓）でモーターが動くか確かめる
2. START（Enter）→ 高速降下（8 mm/s）
3. 台に着く少し手前（左上の「すき間」が 10〜20 mm）で 0mm homing（0 キー）→ 低速（0.5 mm/s）
4. 部品B（の下の部品A）が試験台に当たり、荷重が 0.5 N を超えた瞬間を原点にして 137 mm 上昇
5. 「曲げ治具を取り付ける」で治具と試験片をセットし、試験片名を入力して START
6. 試験（2 mm/分）→ 破断を検知（最大荷重の 70 % 以下が 1 秒）→ 試験開始点まで戻る → 保存（CSV とグラフ4枚）

## 本物と違うところ

- 荷重はデモ値です（最大 10 N 前後で割れる試験片）。
- 保存先フォルダはシミュレーション上のものです。保存したファイルは画面の下に表示され、「⬇」でダウンロードできます。
- 高速のまま試験台にぶつけたとき、または当たったまま 0mm homing を始めたときは、シミュレーターが自動で EMG STOP を押します。
- 137 mm 上昇の速さは 8 mm/s です（元のプログラムは低速 0.5 mm/s のまま上がるため、HOME_UP の前に速度を送る修正を入れた動きにしています）。

## GitHub Pages で公開する手順

1. GitHub で新しいリポジトリを作る（例：`iwear-flexion-simulator`、Public）
2. このフォルダの中身をすべてアップロードする（`Add file` → `Upload files` にドラッグ）
3. `Settings` → `Pages` → `Build and deployment` の `Source` を `Deploy from a branch`、`Branch` を `main` ／ `/ (root)` にして `Save`
4. 1〜2分後、`https://<ユーザー名>.github.io/iwear-flexion-simulator/` で開けます

`index.html` は `model/model.glb` を読み込むので、パソコンで `index.html` をダブルクリックしただけでは 3D が表示されません（ブラウザの制限）。手元で試すときは、このフォルダで `python -m http.server` を実行し、`http://localhost:8000/` を開いてください。

## フォルダの中身

```
index.html                 シミュレーター本体
model/model.glb            装置の 3D モデル（部品・ボルト・Arduino・配線・配線カバー）
model/model.meta.json      試験片やケーブルの位置などの寸法情報
docs/                      README 用の画像
src/viewer3_src.js         3D 表示と、Arduino・PC プログラムの動きを再現するプログラム
src/mkhtml3.py             プログラムと画像をまとめて index.html を作る
src/machine2x.png          プログラム画面の左に出す装置の絵
src/build_model/           STL から 3D モデルを組み立てるプログラム（配線が部品を貫通しないかの確認つき）
```

## 作り直すとき

Python 3 と Node.js が必要です。

```bash
# 3D モデル（部品の位置を変えたときだけ）
cd src/build_model
pip install trimesh manifold3d rtree shapely scipy
python build_asm10.py stl ../../model/model.glb 1 parts/uno_raw.ply --check   # 最後に「hits: 0」なら配線の貫通なし

# index.html
cd ..
npm install
npx esbuild viewer3_src.js --bundle --minify --format=iife --define:ALLOW_DL=true --outfile=viewer3.min.js
python mkhtml3.py ../model/model.glb ../model/model.meta.json ../index.html ext model/model.glb
```

よく変える値は `src/viewer3_src.js` の上のほうにあります（`CONTACT_N`：原点出しの接触判定 0.5 N、`HOME_SPEED_MM_S`：137 mm 上昇の速さ、`newSpecimen()`：デモの試験片の強さ）。

## 使っているもの

- [three.js](https://threejs.org/)（MIT License）— `THIRD_PARTY_NOTICES.md` を参照
- Arduino Uno の 3D モデル：Arduino が公開している Arduino Uno Rev3 のモデルを使用
