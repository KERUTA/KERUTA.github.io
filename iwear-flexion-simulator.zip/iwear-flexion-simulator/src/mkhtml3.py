import sys, base64, json
glb, meta, out = sys.argv[1], sys.argv[2], sys.argv[3]
js = open("viewer3.min.js", encoding="utf-8").read()
b64 = base64.b64encode(open(glb, "rb").read()).decode()
EXT = len(sys.argv) > 4 and sys.argv[4] == "ext"      # 公開ページ用：モデルは別ファイル model.glb
GURL = sys.argv[5] if len(sys.argv) > 5 else "model.b64.txt"
GLBJS = f'window.GLB_URL="{GURL}";' if EXT else f'window.GLB_B64="{b64}";'
META = open(meta).read()
MIMG = base64.b64encode(open("machine2x.png", "rb").read()).decode()

# 左パネルの装置の絵（プログラムの machine.png と同じ雰囲気の線画）
MACHINE = """<svg viewBox="0 0 200 260" width="200" height="260" xmlns="http://www.w3.org/2000/svg">
<g stroke="#333" stroke-width="1.2">
<rect x="22" y="14" width="156" height="18" fill="#e8e8e8"/>
<rect x="40" y="32" width="12" height="178" fill="#7a7d80"/><rect x="148" y="32" width="12" height="178" fill="#7a7d80"/>
<rect x="97" y="32" width="6" height="178" fill="#b9bcc0"/>
<path d="M52 70 h28 l20 22 l20 -22 h28 v44 h-96z" fill="#efefef"/>
<rect x="58" y="96" width="62" height="14" fill="#f4f4f4"/>
<rect x="56" y="112" width="96" height="14" fill="#b4b7ba"/>
<rect x="96" y="115.5" width="22" height="7" rx="3.5" fill="#fff"/>
<rect x="84" y="128" width="62" height="12" fill="#f4f4f4"/>
<rect x="88" y="142" width="34" height="10" fill="#efefef"/>
<rect x="34" y="208" width="132" height="6" fill="#3b6b3a"/>
<rect x="54" y="214" width="92" height="36" fill="#efefef"/>
<rect x="14" y="214" width="34" height="38" fill="#1f3fa8"/><rect x="18" y="220" width="10" height="24" fill="#122a77"/>
<rect x="152" y="214" width="34" height="38" fill="#119a96"/><rect x="170" y="220" width="10" height="24" fill="#0b6b68"/>
</g></svg>"""

CSS = r"""
:root{--blue:#1f4e9a;--blue-l:#e3ebf7;--org:#d9701a;--ink:#15191d;--sub:#5a6470;--line:#d8dee6;--bg:#f3f5f8}
*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;background:var(--bg);color:var(--ink);
font-family:"Hiragino Kaku Gothic ProN","Noto Sans JP","Yu Gothic",Meiryo,sans-serif}
body{display:grid;grid-template-rows:auto minmax(0,1fr)}
header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 14px;background:#fff;border-bottom:1px solid var(--line)}
header h1{font-size:16px;margin:0 8px 0 0;color:var(--blue);white-space:nowrap}
.hb{border:1px solid var(--blue);background:#fff;color:var(--blue);border-radius:7px;padding:6px 11px;font-size:13px;cursor:pointer;font-family:inherit}
.hb.pri{background:var(--org);border-color:var(--org);color:#fff}
.hb:disabled{opacity:.45;cursor:default}
#spd{display:inline-flex;border:1px solid var(--line);border-radius:7px;overflow:hidden;align-items:center}
#spd span{font-size:12px;color:var(--sub);padding:0 8px}
#spd button{border:0;border-left:1px solid var(--line);background:#fff;padding:6px 10px;font-size:12.5px;cursor:pointer;color:var(--sub)}
#spd button.on{background:var(--blue);color:#fff}
.sp{flex:1}
main{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);min-height:0}
#pane3d{position:relative;min-height:0;overflow:hidden;background:#fff}
#view{position:absolute;inset:0}
#stat{position:absolute;left:10px;top:10px;display:flex;flex-direction:column;gap:4px;pointer-events:none}
#stat span{background:rgba(255,255,255,.9);border:1px solid var(--line);border-radius:7px;padding:4px 9px;font-size:12.5px;width:max-content}
#stat span:first-child{border-left:4px solid var(--blue);font-weight:700}
#stepsBox{background:rgba(255,255,255,.95);border:1px solid var(--line);border-radius:10px;font-size:12.5px;box-shadow:0 3px 14px rgba(0,0,0,.07)}
#stepsBox summary{cursor:pointer;padding:7px 11px;font-weight:700;color:var(--blue)}
#steps{list-style:none;margin:0;padding:0 8px 8px;display:grid;grid-template-columns:1fr 1fr;column-gap:6px}
#steps li{display:flex;gap:7px;padding:4px 4px;border-radius:6px;color:var(--sub);line-height:1.45}
#steps li b{flex:0 0 20px;height:20px;border-radius:50%;background:#e6eaf0;color:var(--sub);display:grid;place-items:center;font-size:11px}
#steps li.done b{background:var(--blue-l);color:var(--blue)}
#steps li.cur{background:var(--blue-l);color:var(--ink)}
#steps li.cur b{background:var(--blue);color:#fff}
#toast{position:absolute;left:50%;top:12px;transform:translateX(-50%);background:var(--blue);color:#fff;padding:8px 14px;border-radius:8px;font-size:13px;max-width:90%;box-shadow:0 4px 14px rgba(0,0,0,.15)}
#toast.warn{background:var(--org)}
#panel{position:absolute;top:10px;right:10px;bottom:10px;width:300px;background:#f6f8fb;border:1px solid var(--line);border-radius:12px;display:none;flex-direction:column;box-shadow:0 4px 18px rgba(0,0,0,.08)}
body.parts #panel{display:flex}
#panel header{display:block;padding:10px 12px 8px;border-bottom:1px solid var(--line);background:transparent}
#panel h2{font-size:14px;margin:0 0 7px;color:var(--blue)}
.acts{display:flex;gap:6px}.acts button{flex:1;padding:6px;border:1px solid var(--blue);background:#fff;color:var(--blue);border-radius:7px;font-size:12px;cursor:pointer}
.acts button.pri{background:var(--blue);color:#fff}
#list{overflow:auto;padding:6px 8px 10px;flex:1}
.row{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:5px 6px;border-radius:7px}
.row.sel{background:var(--blue-l)}.nm{font-size:12px;cursor:pointer;flex:1;min-width:0}
.seg{display:flex;border:1px solid var(--line);border-radius:6px;overflow:hidden;flex-shrink:0}
.seg button{border:0;background:#fff;font-size:10.5px;padding:4px 6px;cursor:pointer;color:var(--sub)}
.seg button+button{border-left:1px solid var(--line)}.seg button.on{background:var(--blue);color:#fff}
.seg button[data-s=ghost].on{background:var(--org)}
#info{position:absolute;right:10px;bottom:10px;max-width:min(380px,calc(100% - 20px));background:#fff;border:1px solid var(--line);border-left:5px solid var(--blue);border-radius:10px;padding:10px 12px;box-shadow:0 4px 18px rgba(0,0,0,.08)}
body.parts #info{right:320px}
#info h3{margin:0 0 5px;font-size:14px;color:var(--blue)}#info p{margin:0 0 8px;font-size:12.5px;line-height:1.6}
#info .btns{display:flex;gap:6px}#info button{border:1px solid var(--line);background:#fff;border-radius:6px;padding:4px 9px;font-size:12px;cursor:pointer}
#paneApp{display:flex;flex-direction:column;gap:10px;padding:12px;min-height:0;overflow:auto;background:#dfe4ea;border-left:1px solid var(--line)}
#appHost{flex:none;height:var(--wh);position:relative}
#below{display:flex;flex-direction:column;gap:8px}
#win{position:absolute;left:0;top:0;width:1280px;height:852px;transform-origin:0 0;box-shadow:0 10px 30px rgba(0,0,0,.28);border:1px solid #3a3a3a;overflow:hidden}
#files{background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px 12px;font-size:12.5px}
#files .fh{font-weight:700;color:var(--blue);margin-bottom:3px}#files .fh small{font-weight:400;color:var(--sub)}
#files .fr{color:var(--sub);margin-bottom:6px}
#files .fimgs{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;margin-top:4px}
#files figure{margin:0}#files img{width:100%;border:1px solid var(--line);border-radius:6px;display:block}
#files figcaption{font-size:11px;color:var(--sub);margin-top:2px;word-break:break-all}
#files .fnote{font-size:11.5px;color:var(--sub);margin:6px 0}
#files .fcsv summary{cursor:pointer;color:var(--blue);font-weight:700;margin:4px 0}
#files textarea{width:100%;height:140px;font:11px Consolas,"DejaVu Sans Mono",monospace;border:1px solid var(--line);border-radius:6px;padding:6px;background:#fff;color:var(--ink)}
#files .fdl{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}#files .fdl a{text-decoration:none;font-size:12px}
#csvMsg{font-size:12px;color:var(--sub);margin-left:8px}
body.viewonly main{grid-template-columns:minmax(0,1fr)}
body.viewonly #paneApp,body.viewonly .simonly,body.viewonly #spd{display:none}
.note{font-size:11.5px;color:var(--sub);line-height:1.6}
@media (max-width:900px){
  html,body{overflow:auto;height:auto}
  body{display:block}
  main{display:block}
  #pane3d{height:56vh}
  body.viewonly #pane3d{height:calc(100vh - 110px)}
  #appHost{flex:none;height:var(--wh)}
  #paneApp{overflow:visible}
  #panel{width:auto;left:10px}
  body.parts #info{right:10px}
  #steps{grid-template-columns:1fr}
}
/* ===== プログラム画面（customtkinter dark） ===== */
#win{background:#242424;font-family:"Segoe UI","Roboto","Noto Sans JP",sans-serif;color:#DCE4EE;font-size:13px}
.tb{height:32px;background:#1f1f1f;display:flex;align-items:center;gap:8px;padding-left:10px;color:#fff;font-size:12px;font-family:"Segoe UI",sans-serif}
.tb i{width:16px;height:16px;border-radius:3px;background:linear-gradient(135deg,#3a7bd5,#00979C);display:inline-block}
.tb .simtag{margin-left:auto;margin-right:12px;font-size:11.5px;color:#9fd9db}
.client{height:820px;display:flex;flex-direction:column}
.tbar{height:15px;background:#00979C;flex:none}.tbar2{height:3px;background:#005B5E;flex:none}
.tview{flex:1;margin:0 10px 10px;display:flex;flex-direction:column;min-height:0}
#a_seg{align-self:center;display:flex;background:#4A4D50;border-radius:6px;padding:2px;gap:2px;position:relative;z-index:2;margin-top:4px}
#a_seg button{border:0;border-radius:5px;background:#4A4D50;color:#DCE4EE;font-size:13px;padding:3px 12px;font-family:inherit;cursor:pointer}
#a_seg button.on{background:#00979C}
.tframe{flex:1;background:#1a1a1a;border-radius:6px;margin-top:-13px;padding:22px 6px 6px;min-height:0;display:flex}
#a_tabMain{flex:1;display:grid;grid-template-columns:0.26fr 0.27fr 0.47fr;grid-template-rows:auto minmax(0,1fr);column-gap:10px;min-height:0}
#a_tabMain[hidden],#a_tabGal[hidden]{display:none}
.guid{grid-column:1/4;background:#2b2b2b;border-radius:6px;margin-bottom:10px;text-align:center;padding:10px 6px 6px}
#a_guid{font:bold 18px Meiryo,"Yu Gothic","Noto Sans JP",sans-serif;color:#DCE4EE;min-height:26px}
#a_debug{font:11px Consolas,"DejaVu Sans Mono",monospace;color:#999;margin-top:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lp{background:#E5E5E5;border-radius:15px;margin:5px 0;display:flex;flex-direction:column;align-items:center;overflow:hidden}
.logo{margin:30px 0 20px;width:220px;color:#333;text-align:center;line-height:1}
.logo .s{display:block;font:300 15px "Times New Roman",serif;letter-spacing:.5px;text-align:left;padding-left:44px;color:#555}
.logo .b{display:block;font:300 46px "Didot","Bodoni 72","Times New Roman",serif;letter-spacing:1px;color:#333}
.mc{color:#555;font:bold 12px Arial,sans-serif;margin-top:10px}
#a_mport{color:#888;font:11px Arial,sans-serif;margin-top:2px}
.ctk{border:0;border-radius:6px;color:#DCE4EE;font-family:"Segoe UI","Roboto",sans-serif;font-size:13px;cursor:pointer}
.ctk:disabled{color:#999999;cursor:default}
.ctk:not(:disabled):hover{filter:brightness(.82)}
#a_recon{width:140px;height:32px;background:#555;margin:5px 0}
#a_sstat,#a_mstat{font:13px Meiryo,"Yu Gothic","Noto Sans JP",sans-serif}
#a_sstat{margin-top:20px}#a_mstat{margin-top:5px}
.machine{margin-top:30px}
.cp{background:#222;border-radius:15px;margin:5px 0;display:flex;flex-direction:column;align-items:center;overflow:hidden}
#a_load{font:bold 48px Arial,sans-serif;color:#00979C;margin-top:30px}
#a_loadg{font:16px Arial,sans-serif;color:#888;margin-bottom:5px}
.pbar{width:240px;height:15px;background:#4A4D50;border-radius:8px;margin:10px 0;overflow:hidden}
#a_pb{height:100%;width:0;background:#1F6AA5;border-radius:8px}
#a_entry{width:240px;height:45px;margin:20px 0;background:#343638;border:2px solid #565B5E;border-radius:6px;color:#DCE4EE;font:14px Meiryo,"Yu Gothic","Noto Sans JP",sans-serif;padding:0 9px;outline:none}
#a_entry::placeholder{color:#8e8e8e}
#a_up,#a_down{width:240px;height:40px;background:#3d3d3d;margin:5px 0}
#a_start{width:240px;height:60px;margin:20px 0;font:bold 18px Arial,sans-serif}
#a_zero{width:240px;height:45px;margin:5px 0}
#a_emg{width:240px;height:60px;background:#aa0000;margin:40px 0 10px;font:bold 16px Arial,sans-serif}
.rp{background:#1a1a1a;border-radius:15px;margin:5px 0;padding:10px;min-height:0;overflow:hidden}
#a_plot{display:block}
#a_tabGal{flex:1;padding:20px;display:flex}
.gal{flex:1;background:#111;position:relative;border-radius:6px}
.gal .nav{position:absolute;top:50%;transform:translate(-50%,-50%);width:60px;height:100px;background:#333;font-size:30px}
#a_galImg{position:absolute;left:50%;top:45%;transform:translate(-50%,-50%);color:#555}
#a_galDesc{position:absolute;left:50%;top:85%;transform:translate(-50%,-50%);font:18px Meiryo,"Noto Sans JP",sans-serif;color:#fff;max-width:800px;text-align:center}
.dshade{position:absolute;inset:32px 0 0 0;z-index:9}
.dlg{position:absolute;z-index:10;background:#fff;color:#111;border:2px solid #1f4e9a;border-radius:10px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.45);font:13px "Noto Sans JP","Yu Gothic UI",sans-serif}
.dlg .dtb{height:36px;display:flex;align-items:center;padding:0 0 0 14px;font-size:13.5px;font-weight:700;background:#1f4e9a;color:#fff}
.dlg .dtb .x{color:#fff}
.dlg .dtb .x{margin-left:auto;width:44px;height:100%;border:0;background:none;cursor:pointer;font-size:13px}
#dlgMsg{left:460px;top:330px;width:360px}
#dlgMsg .body{display:flex;gap:14px;padding:18px 20px 22px;align-items:flex-start;white-space:pre-line;line-height:1.6}
#dlgMsg .ic{width:30px;height:30px;flex:none;border-radius:50%;background:#d9701a;color:#fff;font-weight:700;display:grid;place-items:center;font-size:18px}
.dlg .foot{background:#f0f0f0;padding:10px 12px;display:flex;justify-content:flex-end;gap:8px;align-items:center}
.wbtn{min-width:96px;height:30px;border:1px solid #1f4e9a;background:#fff;color:#1f4e9a;border-radius:6px;font:13px "Noto Sans JP",sans-serif;cursor:pointer;padding:0 12px}
.wbtn.defbtn{background:#1f4e9a;color:#fff}
#dlgDir{left:390px;top:260px;width:500px}
#dlgDir[hidden],#dlgMsg[hidden]{display:none}
.dlg .body2{padding:16px 20px 6px;line-height:1.7;font-size:13.5px}
.dlg .fn{display:flex;gap:10px;align-items:center;margin:14px 0 10px;font-size:13.5px}
.dlg .fn input{flex:1;border:1px solid #9fb2d4;border-radius:4px;padding:6px 8px;font:inherit}
"""


HTML = f"""<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Iwear Flexion シミュレーター</title><style>{CSS}</style></head><body>
<header><h1>Iwear Flexion シミュレーター</h1>
<button class="hb" id="bJig">曲げ治具を取り付ける</button>
<button class="hb simonly" id="bSpec">試験片を交換</button>
<span id="spd" class="simonly"><span>速さ</span><button data-v="1">×1</button><button data-v="10">×10</button><button data-v="60">×60</button></span>
<span class="sp"></span>
<button class="hb" id="bParts">部品（半透明）</button>
<button class="hb" id="bMode">見るだけモード</button>
<button class="hb" id="bReset">最初から</button>
</header>
<main>
<section id="pane3d"><div id="view"></div>
<div id="stat"></div>
<div id="toast" hidden></div>
<aside id="panel"><header><h2>部品ごとの表示</h2><div class="acts"><button id="seeInside" class="pri">中を透かして見る</button><button id="allNormal">すべて表示に戻す</button></div></header><div id="list"></div></aside>
<div id="info" hidden><h3></h3><p></p><div class="btns"><button class="ghost">半透明にする／戻す</button><button class="hide">非表示</button><button class="close">閉じる</button></div></div>
</section>
<section id="paneApp">
<div id="appHost"><div id="win">
 <div class="tb">Iwear Flexion - Professional Tester<span class="simtag">シミュレーション画面（iwearflexion_4.py を再現）</span></div>
 <div class="client"><div class="tbar"></div><div class="tbar2"></div>
  <div class="tview"><div id="a_seg"><button class="on" data-tab="main">試験モード</button><button data-tab="gal">試験装置ギャラリー</button></div>
   <div class="tframe">
    <div id="a_tabMain">
     <div class="guid"><div id="a_guid"></div><div id="a_debug"></div></div>
     <div class="lp"><div class="logo"><span class="s">Iwear</span><span class="b">Flexion</span></div>
      <div class="mc">[ Motor Connection ]</div><div id="a_mport">自動検索中...</div>
      <button class="ctk" id="a_recon">🔄 モーター再検索</button>
      <div id="a_sstat">● Load Cell: 未接続</div><div id="a_mstat">● Motor: 未接続</div>
      <div class="machine"><img src="data:image/png;base64,{MIMG}" width="162" height="260" alt=""></div></div>
     <div class="cp"><div id="a_load">0.000 N</div><div id="a_loadg">(0.0 g)</div><div class="pbar"><div id="a_pb"></div></div>
      <input id="a_entry" placeholder="試験片名を入力" autocomplete="off">
      <button class="ctk" id="a_up">UP (↑)</button><button class="ctk" id="a_down">DOWN (↓)</button>
      <button class="ctk" id="a_start">START (Enter)</button>
      <button class="ctk" id="a_zero">0mm homing (0)</button>
      <button class="ctk" id="a_emg">EMG STOP (Esc)</button></div>
     <div class="rp"><canvas id="a_plot"></canvas></div>
    </div>
    <div id="a_tabGal" hidden><div class="gal"><button class="ctk nav" id="a_galPrev" style="left:5%">◀</button><button class="ctk nav" id="a_galNext" style="left:95%">▶</button>
     <div id="a_galImg"></div><div id="a_galDesc"></div></div></div>
   </div></div></div>
 <div class="dshade" id="dlgShade" hidden></div>
 <div class="dlg" id="dlgMsg" hidden><div class="dtb"><span class="dt"></span><button class="x" aria-label="閉じる">×</button></div>
  <div class="body"><span class="ic">!</span><div class="dm"></div></div>
  <div class="foot"><button class="wbtn defbtn">OK</button></div></div>
 <div class="dlg" id="dlgDir" hidden><div class="dtb"><span>保存先フォルダを選ぶ（シミュレーション）</span><button class="x" aria-label="閉じる">×</button></div>
  <div class="body2">本物のプログラムでは、ここでパソコンのフォルダを選ぶ画面が開きます。シミュレーションでは保存先の名前だけ決めます。
  <label class="fn">フォルダ名 <input id="dirName" value="曲げ試験データ"></label></div>
  <div class="foot"><button class="wbtn defbtn">このフォルダに保存</button><button class="wbtn cancel">キャンセル</button></div></div>
</div></div>
<div id="below"><details id="stepsBox" open><summary>使い方の手順（今の段階）</summary><ol id="steps"></ol>
<div class="note" style="padding:0 12px 10px">荷重はデモ値です。原点出しは、部品B（の下の部品A）が試験台に当たって 0.5 N を超えた瞬間で判定します。</div></details>
<div id="files" hidden></div>
<div class="note">プログラム画面は iwearflexion_4.py と同じ動き（キー操作：Enter・0・Esc・↑↓）。保存先はシミュレーション上のもので、保存したグラフと CSV はこの下に表示されます。</div></div>
</section>
</main>
<script>window.SIM_META={META};{GLBJS}</script>
<script>{js}</script></body></html>"""
open(out, "w", encoding="utf-8").write(HTML)
