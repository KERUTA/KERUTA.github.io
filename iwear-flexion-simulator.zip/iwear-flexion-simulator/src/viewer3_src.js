// Iwear Flexion シミュレーター：3D モデル ＋ Arduino（モーター・ロードセル）＋ PC プログラム（iwearflexion_4.py）の再現
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

const META = window.SIM_META;
const $ = (s) => document.querySelector(s);
const q = new URLSearchParams(location.search);

// =====================================================================
//  部品グループ（半透明・非表示・説明）
// =====================================================================
const GROUPS = [
  ["duct", /^配線カバー/, "配線カバー（前・後ろ）", "配線を隠す白いカバー。後ろのカバーは台の専用穴にかぶせ、モーターの4本を右側面の DRV8825 まで通す。前のカバーには、左右の Arduino へ行く配線をまとめて通す。"],
  ["wireM", /^配線M_|^配線_ジャンパー先（(DRV8825|左)）/, "配線：モーター制御", "モーターの4本：台の専用穴 → 後ろの配線カバー → DRV8825。DRV8825 → Arduino①（左）：STEP→D2、DIR→D3、EN→D4、5V、GND。"],
  ["wireL", /^配線L_|^配線_ジャンパー先（(HX711|右)）/, "配線：ロードセル", "ロードセル → HX711（黒いケーブル）。HX711 → Arduino②（右）：DATA→D3、SCK→D2、VCC→5V、GND。"],
  ["wireU", /^配線U_|^USB/, "USB・電源", "Arduino は2台とも USB ハブ経由で PC へ。DRV8825 には外部電源（12〜24 V）。"],
  ["bolt", /ボルト|ねじ/, "ボルト・ねじ", "KP08 は M5、ロードセルは M6、ナット・Arduino・アクリル板は M3。"],
  ["acryl", /^アクリル板/, "アクリル板", "Arduino を台の前面に取り付ける透明な板（3 mm）。"],
  ["base", /^(台|下板)$/, "台・下板", "モーターを中に収める土台。後ろの下に、モーターの配線を通す専用の穴がある。"],
  ["table", /^試験台/, "試験台（緑の板）", "上の板は曲げ治具を載せる試験台。原点出しでは、部品Bの下（部品A）がここに当たった瞬間を検知する。"],
  ["top", /^上部フレーム$/, "上部フレーム", "角パイプの上端をつなぎ、上側の KP08 を固定する。"],
  ["pipe", /^角パイプ/, "角パイプ（ガイド）", "スライダーが傾かずに上下するためのガイド。"],
  ["slider", /^スライダー$/, "スライダー", "ナットでリードスクリューに乗り、角パイプに沿って上下する。"],
  ["screw", /^(リードスクリュー|ナット)/, "リードスクリュー・ナット", "T8 台形ねじ（リード 2 mm）。1/8 マイクロステップで 800 ステップ＝1 mm。"],
  ["kp08", /^KP08/, "KP08 軸受", "リードスクリューの上下を支える軸受。"],
  ["motor", /^(モーター|カップリング)/, "モーター・カップリング", "ステッピングモーター 17HS4401。"],
  ["loadcell", /^ロードセル$/, "ロードセル", "左端をスライダーに固定し、右端（部品B）にかかる力を測る。"],
  ["partB", /^部品B$/, "部品B", "ロードセルの右端に付き、部品Aをぶら下げる。"],
  ["partA", /^部品A$/, "部品A", "T字の溝に圧子の頭をはめて保持する。"],
  ["frame", /^曲げ治具/, "曲げ治具（枠）", "支点間 64 mm の三点曲げ治具。原点出しのときは外しておく。"],
  ["indenter", /^圧子$/, "圧子", "頭を部品Aの溝にはめ、スライダーと一緒に下がって試験片の中央を押す。"],
  ["specimen", /^試験片$/, "試験片", "JIS K 7171 短冊形（80×10×4 mm）。"],
  ["ardL", /（左・モーター制御用）/, "Arduino①（左・モーター制御）", "PC の命令（UP・DOWN・HOME_UP・START_TEST・FRACTURE など）を受け、DRV8825 にパルスを送る。"],
  ["ardR", /（右・ロードセル用）/, "Arduino②（右・ロードセル）", "HX711 から荷重を読み、「L:グラム」を 1 秒に 50 回 PC へ送る。"],
  ["drv", /^DRV8825/, "DRV8825 基板", "Arduino のパルスでモーターに電流を流す。"],
  ["hx", /^HX711/, "HX711", "ロードセルの信号を増幅して Arduino② に渡す。"],
];
const groupOf = (n) => { for (const g of GROUPS) if (g[1].test(n)) return g[0]; return "other"; };

// =====================================================================
//  定数（iwearflexion_4.py と Arduino のプログラムから）
// =====================================================================
const STEPS_PER_MM = 800, MAX_LOAD_N = 400.0, TEST_SPEED_MM_MIN = 2.0;
const SPAN_L = 64.0, WIDTH_B = 10.0, THICK_H = 4.0;
const CONTACT_N = 0.5;                         // 原点出しの接触判定（ご指定どおり 0.5 N）
const STEPS_137MM = 137 * 800;
const HOME_SPEED_MM_S = 8.0;                   // 137 mm 上昇の速さ（高速降下と同じ）
const SENSOR_PORT = "COM13", MOTOR_PORT = "COM5";
const ACCENT = "#00979C";

// 機構（3D モデルの実測）
const H_CONTACT = META.z_table - 244.5;        // 部品Aの下面が試験台に当たるスライダー位置（モデルの組立位置＝0）
const H_MAX = 422.5 - 382.5;                   // ナットの上が上の KP08 に当たる
const H_JIG_CRASH = -26.0;                     // 治具ありで部品Aが治具の枠に当たる
const K_HARD = 400.0, STALL_N = 150.0;         // 当たったときのばね定数 [N/mm]・モーターが脱調する力
const OFFSET_G = 8.0;                          // ロードセルのゼロのずれ（IDLE で 0.07 N くらい）

// =====================================================================
//  シミュレーションの状態
// =====================================================================
let simT = 0, speed = +(q.get("spd") || 1);
const mech = { H: 30.0, stall: false, crashWarned: false };
const jig = { attached: false, anim: 1, from: 0, to: 0, t0: 0 };
const spec = { broken: false, dBreak: 0, Fp: 10.4, dp: 1.15, dc: 2.0, maxDelta: 0 };
newSpecimen();

function newSpecimen() {
  spec.broken = false; spec.dBreak = 0; spec.maxDelta = 0;
  spec.Fp = 9.6 + Math.random() * 1.8;
  spec.dp = 1.0 + Math.random() * 0.3;
  spec.dc = spec.dp + 0.55 + Math.random() * 0.25;
}
function gauss() { return Math.sqrt(-2 * Math.log(Math.random() + 1e-12)) * Math.cos(2 * Math.PI * Math.random()); }

// 荷重（デモ値）[N]：スライダー位置 H から
function specimenForce(d) {
  if (d <= 0) return 0;
  if (spec.broken) return d > -H_JIG_CRASH ? K_HARD * (d + H_JIG_CRASH) : 0.35 * Math.exp(-(d - spec.dBreak) / 0.4);
  const { Fp, dp, dc } = spec;
  let F;
  if (d < dp) {
    F = Fp * (1 - Math.pow(1 - d / dp, 2.2));
    F *= 1 - 0.03 * Math.exp(-((d % 0.17) / 0.015));      // 層がずれるときの小さな段差
  } else {
    F = Fp * (1 - 0.18 * Math.pow((d - dp) / (dc - dp), 1.6));
  }
  return Math.max(F, 0);
}
function loadAt(H) {
  let F = 0;
  if (jig.attached) {
    const d = -H;
    F = specimenForce(d);
    if (H < H_JIG_CRASH) F += K_HARD * (H_JIG_CRASH - H);
  } else if (H < H_CONTACT) F = K_HARD * (H_CONTACT - H);
  return F;
}
function mechMove(dh) {
  if (dh < 0) {
    const nh = mech.H + dh;
    if (loadAt(nh) > STALL_N) { mech.stall = true; return; }   // 脱調（ステップは数えるが動かない）
    mech.H = nh;
    if (jig.attached && !spec.broken && -mech.H >= spec.dc) { spec.broken = true; spec.dBreak = -mech.H; }
    if (jig.attached) spec.maxDelta = Math.max(spec.maxDelta, -mech.H);
  } else {
    if (mech.H + dh > H_MAX) { mech.H = H_MAX; mech.stall = true; return; }
    mech.H += dh;
  }
  mech.stall = false;
}

// =====================================================================
//  Arduino①（モーター制御）：配布されたプログラムの動き
// =====================================================================
const ard = { state: "IDLE", steps: 0, interval: 500, up: false, homing: 0, acc: 0, lastRep: 0 };
function ardCmd(cmd) {
  cmd = cmd.trim();
  if (cmd.startsWith("SPEED:")) ard.interval = parseInt(cmd.slice(6)) || 0;
  else if (cmd === "UP") setMov(true, "MOVING");
  else if (cmd === "DOWN") setMov(false, "MOVING");
  else if (cmd === "STOP") stopMotor();
  else if (cmd === "RESET_POS") ard.steps = 0;
  else if (cmd === "START_TEST") { ardSend("TEST_START"); setMov(false, "TESTING"); }
  else if (cmd === "HOME_UP") { ard.homing = STEPS_137MM; setMov(true, "HOMING"); }
  else if (cmd === "FRACTURE") { ardSend("RETURNING"); setMov(true, "RETURNING"); }
  else if (cmd === "GET_POS") ardSend("P:" + ard.steps);
}
function setMov(up, st) { ard.up = up; ard.state = st; }
function stopMotor() { if (ard.state === "RETURNING") ardSend("TEST_DONE"); ard.state = "IDLE"; }
function ardTick(dt) {
  if (ard.state !== "IDLE" && ard.interval > 0) {
    ard.acc += dt * 1e6 / ard.interval;
    let k = Math.floor(ard.acc); ard.acc -= k;
    if (ard.state === "HOMING") k = Math.min(k, ard.homing);
    if (ard.state === "RETURNING" && ard.up) k = Math.min(k, Math.max(ard.steps, 1));
    if (k > 0) {
      ard.steps += ard.up ? -k : k;
      mechMove((ard.up ? 1 : -1) * k / STEPS_PER_MM);
      if (ard.state === "HOMING") { ard.homing -= k; if (ard.homing <= 0) { ardSend("HOMING_DONE"); stopMotor(); } }
      else if (ard.state === "RETURNING") { if (ard.steps <= 0) { ard.steps = 0; stopMotor(); } }
    }
  } else ard.acc = 0;
  if (simT - ard.lastRep > 0.05) { ardSend("P:" + ard.steps); ard.lastRep = simT; }
}
function ardSend(line) { if (pc.motorOk) pcMotorLine(line); }

// Arduino②（ロードセル）：20 ms ごとに "L:グラム"
let lastSensor = 0;
function sensorTick() {
  if (simT - lastSensor < 0.02) return;
  lastSensor = simT;
  const g = loadAt(mech.H) / 9.81 * 1000 + OFFSET_G + gauss() * 1.2;
  pcSensorLine("L:" + g.toFixed(3));
}

// =====================================================================
//  PC プログラム（iwearflexion_4.py の TesterApp を移植）
// =====================================================================
const pc = {
  sys: "IDLE", raw: 0, zero: 0, g: 0, n: 0, maxLoad: 0, steps: 0, ard: "IDLE",
  fract: false, fractStart: 0, lastRx: "(受信なし)", disp: [], load: [],
  idleT: [], idleL: [], sensorOk: true, motorOk: false, saveDir: "", sample: "", files: [],
};
const seq = { active: false, phase: "", until: 0, nextTest: 0 };

function pcSensorLine(line) {
  if (line.startsWith("L:")) {
    pc.raw = parseFloat(line.split(":")[1]);
    pc.g = pc.raw - pc.zero;
    pc.n = (pc.g / 1000.0) * 9.81;
  }
}
function pcMotorLine(line) {
  if (line) pc.lastRx = line;
  if (line.startsWith("P:")) pc.steps = parseInt(line.split(":")[1]);
  else if (line === "HOMING_DONE") pc.ard = "HOMING_DONE";
  else if (line === "TEST_START") pc.ard = "TESTING";
  else if (line === "RETURNING") pc.ard = "RETURNING";
  else if (line === "TEST_DONE") pc.ard = "IDLE";
}
const sendM = (c) => { if (pc.motorOk) ardCmd(c); };
const speedCmd = (mmps) => `SPEED:${Math.trunc(1000000 / (STEPS_PER_MM * mmps))}`;

function changeState(st, guidance) {
  pc.sys = st;
  ui.guid.textContent = `[${st}] ${guidance}`;
  const manualOk = ["IDLE", "FINISHED"].includes(st);
  setBtn(ui.up, manualOk); setBtn(ui.down, manualOk);
  updateStartButton(true);
  const z = st === "FAST_DOWN";
  setBtn(ui.zero, z, z ? ACCENT : "#555555");
  if (st === "FAST_DOWN") { sendM(speedCmd(8.0)); sendM("DOWN"); }
  else if (st === "SLOW_DOWN") { sendM(speedCmd(0.5)); sendM("DOWN"); }
  else if (st === "TESTING") {
    pc.disp = []; pc.load = []; pc.maxLoad = 0; pc.steps = 0; pc.fract = false; pc.fractStart = 0; pc.ard = "STARTING";
    sendM("RESET_POS");
    sendM(speedCmd(TEST_SPEED_MM_MIN / 60.0));
    sendM("START_TEST");
  }
  stepGuide();
}
function updateStartButton(force) {
  if (force || ["IDLE", "WAIT_TEST", "FINISHED"].includes(pc.sys)) {
    const ok = ["IDLE", "WAIT_TEST", "FINISHED"].includes(pc.sys) && pc.sensorOk && pc.motorOk;
    setBtn(ui.start, ok, ok ? ACCENT : "#555555");
  }
}
function actionStart() {
  if (modalOpen()) return;
  if (!(pc.sensorOk && pc.motorOk)) { msgbox("未接続", "センサーまたはモーターが接続されていません。\n接続を確認してください。"); return; }
  if (pc.sys === "IDLE") changeState("FAST_DOWN", "高速降下中。接触前に '0'キー または ボタンで homing開始。");
  else if (["WAIT_TEST", "FINISHED"].includes(pc.sys)) {
    const sample = ui.entry.value.trim();
    if (!sample) { msgbox("入力エラー", "試験片名を入力してください。"); return; }
    folderDialog((folder) => {
      if (folder) { pc.saveDir = folder; pc.sample = sample; changeState("TESTING", "試験中... Arduinoが自律制御します。"); }
    });
  }
}
function action0mm() { if (modalOpen()) return; if (pc.sys === "FAST_DOWN") { sendM("STOP"); changeState("SLOW_DOWN", "低速(0.5mm/s)で接触を検知しています..."); } }
function actionEmg() { if (modalOpen()) return; sendM("STOP"); changeState("IDLE", "緊急停止しました。機械の状態を確認してください。"); }
function manualMove(dir) { if (["IDLE", "FINISHED"].includes(pc.sys)) { sendM(speedCmd(5.0)); sendM(dir); } }
function manualStop() { if (["IDLE", "FINISHED"].includes(pc.sys)) sendM("STOP"); }

// モーターの自動検索（GET_POS に P: が返るポートを探す）
let motorSearch = null;
function autoConnectMotor() {
  pc.motorOk = false;
  ui.mport.textContent = "自動検索中...";
  ui.mstat.textContent = "● Motor: 検索中..."; ui.mstat.style.color = "#888888";
  updateStartButton();
  motorSearch = simT + 1.8;
}
function motorSearchTick() {
  if (motorSearch !== null && simT >= motorSearch) {
    motorSearch = null; pc.motorOk = true;
    ui.mport.textContent = `検出: ${MOTOR_PORT}`;
    ui.mstat.textContent = `🟢 Motor: ${MOTOR_PORT} 接続中`; ui.mstat.style.color = "#228B22";
    updateStartButton();
  }
}

// sequence_thread
function seqTick() {
  if (!seq.active && pc.sys === "SLOW_DOWN") {
    seq.active = true; pc.zero = pc.raw; seq.phase = "detect"; seq.zeroF = loadAt(mech.H);
    if (seq.zeroF > 0.5) { safetyStop("すでに当たっている状態で 0mm homing を始めました（このままだとゼロ点がずれます）"); return; }
  }
  if (seq.active) {
    if (seq.phase === "detect") {
      if (pc.sys !== "SLOW_DOWN") { seq.active = false; return; }
      if (pc.n >= CONTACT_N) { sendM("STOP"); seq.phase = "w03"; seq.until = simT + 0.3; }
    } else if (seq.phase === "w03" && simT >= seq.until) {
      ui.guid.textContent = "接触検知！Arduinoが137mm上昇します...";
      sendM(speedCmd(HOME_SPEED_MM_S));   // 修正：上昇の前に速度を指定（元のコードは 0.5 mm/s のまま 137 mm 上がっていた）
      sendM("HOME_UP"); pc.ard = ""; seq.phase = "whome"; seq.until = simT + 30;
    } else if (seq.phase === "whome" && (pc.ard === "HOMING_DONE" || simT >= seq.until)) {
      seq.active = false;
      changeState("WAIT_TEST", "原点復帰完了。試験片名を入力してEnterで本試験を開始してください。");
    }
    return;
  }
  if (pc.sys === "TESTING" && simT >= seq.nextTest) {
    seq.nextTest = simT + 0.15;
    const disp = pc.steps / STEPS_PER_MM;
    if (!pc.fract) {
      pc.disp.push(disp); pc.load.push(pc.n);
      if (pc.n > pc.maxLoad) { pc.maxLoad = pc.n; pc.fractStart = 0; }
      let broke = false;
      if (pc.maxLoad > 2.0 && pc.n <= pc.maxLoad * 0.70) {
        if (pc.fractStart === 0) pc.fractStart = simT;
        else if (simT - pc.fractStart >= 1.0) broke = true;
      } else pc.fractStart = 0;
      const maxed = disp >= 14.9;
      if (broke || maxed) {
        pc.fract = true; sendM("FRACTURE");
        ui.guid.textContent = broke ? "[TESTING] 破断確定！Arduinoが復帰中..." : "[TESTING] 最大変位到達！Arduinoが復帰中...";
      }
    }
    if (pc.ard === "IDLE" && pc.fract) {
      changeState("SAVING", "データを保存中...");
      saveTestData();
      changeState("FINISHED", "試験完了。結果を保存しました。試験片名を入力してEnterで次の試験へ。");
      ui.entry.value = "";
    }
  }
}

// 画面の更新（update_ui_fast：50 ms、update_graph_loop：200 ms）
let lastUi = 0, lastGraph = 0, graphDirty = true;
function uiTick() {
  if (simT - lastUi >= 0.05) {
    lastUi = simT;
    ui.load.textContent = `${pc.n.toFixed(3)} N`;
    ui.loadg.textContent = `(${pc.g.toFixed(1)} g)`;
    ui.pb.style.width = `${Math.max(0, Math.min(pc.n / MAX_LOAD_N, 1)) * 100}%`;
    ui.debug.textContent = `[DEBUG] sys=${pc.sys} / arduino=${pc.ard} / steps=${pc.steps} / pts=${pc.disp.length} / last_rx="${pc.lastRx}"`;
  }
  if (simT - lastGraph >= 0.2) {
    lastGraph = simT;
    if (!(pc.sys === "TESTING" && pc.disp.length)) {
      pc.idleT.push(simT); pc.idleL.push(pc.n);
      if (pc.idleT.length > 200) { pc.idleT.shift(); pc.idleL.shift(); }
    }
    graphDirty = true;
  }
}

// =====================================================================
//  データ保存（CSV と グラフ PNG）
// =====================================================================
function calcStress(F) { return (3.0 * F * SPAN_L) / (2.0 * WIDTH_B * THICK_H ** 2); }
function calcStrain(d) { return (6.0 * d * THICK_H) / SPAN_L ** 2; }
function calcModulus(D, L) {
  if (L.length < 5) return NaN;
  const mx = Math.max(...L);
  const idx = L.map((v, i) => i).filter((i) => L[i] >= mx * 0.1 && L[i] <= mx * 0.4);
  if (idx.length < 3) return NaN;
  const xs = idx.map((i) => D[i]), ys = idx.map((i) => L[i]);
  const n = xs.length, mxx = xs.reduce((a, b) => a + b) / n, myy = ys.reduce((a, b) => a + b) / n;
  let sxy = 0, sxx = 0;
  for (let i = 0; i < n; i++) { sxy += (xs[i] - mxx) * (ys[i] - myy); sxx += (xs[i] - mxx) ** 2; }
  if (sxx === 0) return NaN;
  return (SPAN_L ** 3) / (4.0 * WIDTH_B * THICK_H ** 3) * (sxy / sxx);
}
function pyFixed(v, k) { return Number.isNaN(v) ? "nan" : v.toFixed(k); }
function saveTestData() {
  const D = pc.disp.slice(), L = pc.load.slice(), S = L.map(calcStress), E = D.map(calcStrain);
  if (!D.length) return;
  let mi = 0; L.forEach((v, i) => { if (v > L[mi]) mi = i; });
  const em = calcModulus(D, L);
  const now = new Date(), p2 = (x) => String(x).padStart(2, "0");
  const ts = `${now.getFullYear()}-${p2(now.getMonth() + 1)}-${p2(now.getDate())} ${p2(now.getHours())}:${p2(now.getMinutes())}:${p2(now.getSeconds())}`;
  let csv = `# 試料名,${pc.sample}\n# 試験日時,${ts}\n# 結果: 最大荷重,${L[mi].toFixed(3)},N, 最大曲げ応力,${S[mi].toFixed(4)},MPa, 弾性率,${pyFixed(em, 1)},MPa\n`;
  csv += "Time(s),Displacement(mm),Load(N),Strain,Stress(MPa)\n";
  for (let i = 0; i < D.length; i++) {
    const t = D[i] / (TEST_SPEED_MM_MIN / 60.0);
    csv += `${t.toFixed(3)},${D[i].toFixed(4)},${L[i].toFixed(3)},${E[i].toFixed(6)},${S[i].toFixed(4)}\n`;
  }
  const files = [];
  files.push({ name: `${pc.sample}.csv`, text: csv });
  const mk = (x, y, title, xl, yl, mx, my, ml, col, fs, fn) => {
    const c = document.createElement("canvas"); c.width = fs[0] * 150; c.height = fs[1] * 150;
    drawPlot(c.getContext("2d"), c.width, c.height, x, y, { theme: "save", color: col, title: `${title}  [${pc.sample}]`, xl, yl, mark: [mx, my, ml], dpi: 150 });
    files.push({ name: fn, url: c.toDataURL("image/png") });
  };
  mk(D, L, "Load-Displacement", "Displacement [mm]", "Load [N]", D[mi], L[mi], `${L[mi].toFixed(2)}N`, "#005B5E", [7, 4], `${pc.sample}_FD_Graph_7x4.png`);
  mk(D, L, "Load-Displacement", "Displacement [mm]", "Load [N]", D[mi], L[mi], `${L[mi].toFixed(2)}N`, "#005B5E", [8, 5], `${pc.sample}_FD_Graph_8x5.png`);
  mk(E, S, "Stress-Strain", "Strain [-]", "Stress [MPa]", E[mi], S[mi], `${S[mi].toFixed(2)}MPa`, "#FF6347", [7, 4], `${pc.sample}_SS_Graph_7x4.png`);
  mk(E, S, "Stress-Strain", "Strain [-]", "Stress [MPa]", E[mi], S[mi], `${S[mi].toFixed(2)}MPa`, "#FF6347", [8, 5], `${pc.sample}_SS_Graph_8x5.png`);
  pc.files = files;
  renderFiles(`${pc.saveDir}/${pc.sample}/`, L[mi], S[mi], em);
}

// =====================================================================
//  matplotlib 風のグラフ
// =====================================================================
function niceTicks(lo, hi, nb) {
  const span = hi - lo; if (!(span > 0)) return [lo];
  const raw = span / nb, mag = Math.pow(10, Math.floor(Math.log10(raw)));
  let step = 10 * mag;
  for (const s of [1, 2, 2.5, 5, 10]) if (s * mag >= raw) { step = s * mag; break; }
  const out = []; for (let v = Math.ceil(lo / step - 1e-9) * step; v <= hi + step * 1e-9; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : v);
  return out;
}
function fmtTick(v, ticks) {
  const step = ticks.length > 1 ? Math.abs(ticks[1] - ticks[0]) : 1;
  const dec = Math.max(0, -Math.floor(Math.log10(step) + 1e-9) + (step / Math.pow(10, Math.floor(Math.log10(step))) === 2.5 ? 1 : 0));
  let s = v.toFixed(Math.min(dec, 6));
  if (s.startsWith("-") && parseFloat(s) === 0) s = s.slice(1);
  return s.replace("-", "−");
}
function drawPlot(ctx, W, H, xs, ys, o) {
  const dpi = o.dpi || 100, pt = dpi / 72, fs = 10 * pt;
  const save = o.theme === "save";
  const bg = save ? "#ffffff" : "#1a1a1a", fg = o.theme === "test" ? "#ffffff" : "#000000";
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
  let L = 0.125 * W, R = 0.9 * W, T = 0.12 * H, B = 0.89 * H;
  if (save) { L = 0.11 * W; R = 0.97 * W; T = 0.1 * H; B = 0.86 * H; }
  if (!xs.length) { // 空の Axes
    xs = [0, 1]; ys = [0, 1]; o = { ...o, empty: true };
  }
  let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (o.mark) { x0 = Math.min(x0, o.mark[0]); x1 = Math.max(x1, o.mark[0]); y0 = Math.min(y0, o.mark[1]); y1 = Math.max(y1, o.mark[1]); }
  if (x1 - x0 < 1e-12) { x0 -= 0.055; x1 += 0.055; } else { const m = (x1 - x0) * 0.05; x0 -= m; x1 += m; }
  if (y1 - y0 < 1e-12) { y0 -= Math.abs(y0) * 0.05 || 0.055; y1 += Math.abs(y1) * 0.05 || 0.055; } else { const m = (y1 - y0) * 0.05; y0 -= m; y1 += m; }
  const X = (v) => L + (v - x0) / (x1 - x0) * (R - L), Y = (v) => B - (v - y0) / (y1 - y0) * (B - T);
  if (save) { ctx.strokeStyle = "rgba(176,176,176,0.5)"; ctx.setLineDash([4 * pt, 2 * pt]); ctx.lineWidth = 0.8 * pt; }
  const xt = niceTicks(x0, x1, Math.max(3, Math.min(9, Math.floor((R - L) / (fs * 4))))).filter((v) => v >= x0 && v <= x1);
  const yt = niceTicks(y0, y1, Math.max(3, Math.min(9, Math.floor((B - T) / (fs * 2.2))))).filter((v) => v >= y0 && v <= y1);
  if (save) {
    ctx.beginPath(); for (const v of xt) { ctx.moveTo(X(v), T); ctx.lineTo(X(v), B); } for (const v of yt) { ctx.moveTo(L, Y(v)); ctx.lineTo(R, Y(v)); } ctx.stroke(); ctx.setLineDash([]);
  }
  // 線
  if (!o.empty) {
    ctx.save(); ctx.beginPath(); ctx.rect(L, T, R - L, B - T); ctx.clip();
    ctx.strokeStyle = o.color; ctx.lineWidth = (save ? 2 : 1.5) * pt; ctx.lineJoin = "round"; ctx.beginPath();
    xs.forEach((v, i) => (i ? ctx.lineTo(X(v), Y(ys[i])) : ctx.moveTo(X(v), Y(ys[i])))); ctx.stroke(); ctx.restore();
  }
  // 枠と目盛
  ctx.strokeStyle = "#000"; ctx.lineWidth = 0.8 * pt; ctx.strokeRect(L, T, R - L, B - T);
  ctx.fillStyle = fg; ctx.strokeStyle = fg; ctx.font = `${fs}px "DejaVu Sans", Verdana, Arial, sans-serif`;
  ctx.textAlign = "center"; ctx.textBaseline = "top";
  ctx.beginPath();
  for (const v of xt) { ctx.moveTo(X(v), B); ctx.lineTo(X(v), B + 3.5 * pt); ctx.fillText(fmtTick(v, xt), X(v), B + 5 * pt); }
  ctx.textAlign = "right"; ctx.textBaseline = "middle";
  for (const v of yt) { ctx.moveTo(L, Y(v)); ctx.lineTo(L - 3.5 * pt, Y(v)); ctx.fillText(fmtTick(v, yt), L - 5 * pt, Y(v)); }
  ctx.stroke();
  if (o.xl) { ctx.textAlign = "center"; ctx.textBaseline = "top"; ctx.fillText(o.xl, (L + R) / 2, B + 5 * pt + fs * 1.5); }
  if (o.yl) {
    ctx.save(); ctx.translate(L - fs * 3.6, (T + B) / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = "center"; ctx.textBaseline = "bottom"; ctx.fillText(o.yl, 0, 0); ctx.restore();
  }
  if (o.title) { ctx.font = `${fs * 1.2}px "Meiryo","Yu Gothic","Noto Sans JP",sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "bottom"; ctx.fillStyle = "#000"; ctx.fillText(o.title, (L + R) / 2, T - 6 * pt); }
  if (o.mark) {
    ctx.fillStyle = "red"; ctx.beginPath(); ctx.arc(X(o.mark[0]), Y(o.mark[1]), 3.5 * pt, 0, 7); ctx.fill();
    ctx.font = `${fs}px "DejaVu Sans", Verdana, sans-serif`; ctx.textAlign = "left"; ctx.textBaseline = "bottom";
    ctx.fillText(o.mark[2], X(o.mark[0]) + 10 * pt, Y(o.mark[1]) - 5 * pt);
  }
}
function renderGraph() {
  const c = ui.plot, r = c.parentElement.getBoundingClientRect(), sc = winScale || 1;
  const w = Math.round((r.width / sc - 20)), h = Math.round((r.height / sc - 20));
  if (w <= 0 || h <= 0) return;
  const k = 2;
  if (c.width !== w * k || c.height !== h * k) { c.width = w * k; c.height = h * k; c.style.width = w + "px"; c.style.height = h + "px"; }
  const ctx = c.getContext("2d"); ctx.setTransform(k, 0, 0, k, 0, 0);
  if (pc.sys === "TESTING" && pc.disp.length) {
    const n = Math.min(pc.disp.length, pc.load.length);
    drawPlot(ctx, w, h, pc.disp.slice(0, n), pc.load.slice(0, n), { theme: "test", color: "#00FFFF", xl: "Displacement (mm)", yl: "Load (N)" });
  } else if (pc.idleT.length > 1) {
    const tl = pc.idleT[pc.idleT.length - 1];
    drawPlot(ctx, w, h, pc.idleT.map((t) => t - tl), pc.idleL, { theme: "idle", color: ACCENT });
  } else drawPlot(ctx, w, h, [], [], { theme: "idle" });
}

// =====================================================================
//  プログラム画面（customtkinter の見た目を再現）
// =====================================================================
const GALLERY = {
  1: "この試験装置の配線図です。動かなくなった時に確認してみてください。", 2: "【試験装置の変遷】最初期",
  3: "【試験装置の変遷】ここまで作りようやく回転運動を直線運動にすることができた。",
  4: "【試験装置の変遷】ロードセルを取り付けてみた。しかし、ロードセルの先端に力を加えるとリードスクリューが回らなくなってしまい、設計を見直すこととなった",
  5: "【試験装置の変遷】ロードセルを横に取り付けるようにしガイドレールをつかむ面積も増やし、リードスクリューに斜め方向からの力がかからないようにした。",
  6: "【試験装置の変遷】物理スイッチで操作するのをやめ、Pythonと通信して動くようにして。遂に試験装置<iwear flexion>が完成した",
  7: "ステッピングモーターの制御を担当するarduino", 8: "ロードセルの制御を担当するarduino", 9: "試験装置を作成する際にまとめた企画書", 10: "最高にカッコイイ画角",
};
const ui = {};
function setBtn(b, on, color) { b.disabled = !on; if (color) b.style.background = color; }
function buildApp() {
  for (const id of ["guid", "debug", "mport", "mstat", "sstat", "load", "loadg", "pb", "entry", "up", "down", "start", "zero", "emg", "plot", "recon", "galImg", "galDesc"]) ui[id] = document.getElementById("a_" + id);
  ui.sstat.textContent = `🟢 Load Cell: ${SENSOR_PORT} 接続中`; ui.sstat.style.color = "#228B22";
  // ボタン
  const hold = (b, dir) => {
    b.addEventListener("pointerdown", (e) => { if (!b.disabled) { b.setPointerCapture(e.pointerId); manualMove(dir); } });
    b.addEventListener("pointerup", () => manualStop());
  };
  hold(ui.up, "UP"); hold(ui.down, "DOWN");
  ui.start.onclick = actionStart; ui.zero.onclick = action0mm; ui.emg.onclick = actionEmg;
  ui.recon.onclick = autoConnectMotor;
  // タブ
  document.querySelectorAll("#a_seg button").forEach((b) => b.onclick = () => {
    document.querySelectorAll("#a_seg button").forEach((x) => x.classList.toggle("on", x === b));
    $("#a_tabMain").hidden = b.dataset.tab !== "main"; $("#a_tabGal").hidden = b.dataset.tab !== "gal";
    graphDirty = true;
  });
  $("#a_galPrev").onclick = () => moveGallery(-1); $("#a_galNext").onclick = () => moveGallery(1);
  moveGallery(0);
  // キー操作（Tk のルートにバインドされたキー）
  const held = {};
  window.addEventListener("keydown", (e) => {
    if (document.body.classList.contains("viewonly")) return;
    if (modalOpen()) { if (e.key === "Enter") { const b = document.querySelector(".dlg:not([hidden]) .defbtn"); b && b.click(); e.preventDefault(); }
      else if (e.key === "Escape") { const b = document.querySelector(".dlg:not([hidden]) .x"); b && b.click(); }
      return; }
    if (e.key === "ArrowUp") { manualMove("UP"); held.u = 1; e.preventDefault(); }
    else if (e.key === "ArrowDown") { manualMove("DOWN"); held.d = 1; e.preventDefault(); }
    else if (e.key === "Enter") { actionStart(); e.preventDefault(); }
    else if (e.key === "Escape") actionEmg();
    else if (e.key === "0") action0mm();
    else if (e.key === "ArrowLeft" && document.activeElement !== ui.entry) moveGallery(-1);
    else if (e.key === "ArrowRight" && document.activeElement !== ui.entry) moveGallery(1);
  });
  window.addEventListener("keyup", (e) => { if (e.key === "ArrowUp" || e.key === "ArrowDown") manualStop(); });
}
let galIdx = 1;
function moveGallery(d) {
  galIdx = Math.max(1, Math.min(10, galIdx + d));
  ui.galImg.textContent = `画像なし (${galIdx}.png)`;
  ui.galDesc.textContent = `No.${galIdx} : ${GALLERY[galIdx] || "説明文なし"}`;
}
// ダイアログ
function modalOpen() { return !!document.querySelector(".dlg:not([hidden])"); }
function msgbox(title, text) {
  const d = $("#dlgMsg"); d.querySelector(".dt").textContent = title; d.querySelector(".dm").textContent = text;
  d.hidden = false; $("#dlgShade").hidden = false;
  d.querySelector(".defbtn").onclick = d.querySelector(".x").onclick = () => { d.hidden = true; $("#dlgShade").hidden = true; };
}
function folderDialog(cb) {
  const d = $("#dlgDir"); d.hidden = false; $("#dlgShade").hidden = false;
  const close = (v) => { d.hidden = true; $("#dlgShade").hidden = true; cb(v); };
  d.querySelector(".defbtn").onclick = () => close(($("#dirName").value || "曲げ試験データ").trim());
  d.querySelector(".cancel").onclick = () => close("");
  d.querySelector(".x").onclick = () => close("");
}

// =====================================================================
//  3D
// =====================================================================
const view = $("#view");
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(+(q.get("pr") || window.devicePixelRatio || 1), 2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
view.appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color("#ffffff");
const pmrem = new THREE.PMREMGenerator(renderer); scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
const cam = new THREE.PerspectiveCamera(28, 1, 1, 10000); cam.up.set(0, 0, 1);
scene.add(new THREE.HemisphereLight(0xffffff, 0xb8c0c8, 0.55));
const sun = new THREE.DirectionalLight(0xffffff, 1.25); sun.position.set(-400, -700, 1100); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -450, right: 450, top: 450, bottom: -450, near: 10, far: 3000 });
sun.shadow.bias = -0.0005; scene.add(sun);
const fill = new THREE.DirectionalLight(0xffffff, 0.45); fill.position.set(600, 300, 400); scene.add(fill);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(4000, 4000), new THREE.ShadowMaterial({ opacity: 0.18 })); ground.receiveShadow = true; scene.add(ground);

const groups = {};
const movers = [], rotors = [], jigFrame = [], jigInd = [];
let ctl, selected = null, cableMesh = null, specHalves = [];
function addToGroup(o, k) { (groups[k] = groups[k] || { meshes: [], state: "normal" }).meshes.push(o); o.userData.group = k; }

// 3D モデル：HTML に埋め込み（パソコン用）か、横に置いた model.glb を読む（公開ページ用）
const loadModel = window.GLB_URL
  ? fetch(window.GLB_URL).then((r) => {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return /\.txt$/.test(window.GLB_URL) ? r.text().then((t) => Uint8Array.from(atob(t.trim()), (c) => c.charCodeAt(0)).buffer) : r.arrayBuffer();
    })
  : Promise.resolve(Uint8Array.from(atob(window.GLB_B64), (c) => c.charCodeAt(0)).buffer);
loadModel.then((bin) => new GLTFLoader().parse(bin, "", (g) => {
  const all = []; g.scene.traverse((o) => { if (o.isMesh) all.push(o); });
  for (const o of all) {
    o.castShadow = true; o.receiveShadow = true;
    const c = o.geometry.attributes.color, col = new THREE.Color();
    if (c) { col.setRGB(c.getX(0), c.getY(0), c.getZ(0)); o.geometry.deleteAttribute("color"); }
    const n = o.name;
    if (n === "試験片" || n === "配線L_ロードセルのケーブル") { o.parent.remove(o); continue; }
    const elec = /^(DRV8825|HX711|Arduino（|配線|USB)|コネクタ/.test(n);
    const metal = !elec && /リード|ナット|KP08|カップリング|パイプ|モーター|軸|ボルト|ねじ/.test(n) && !/_1$/.test(n);
    const alu = /ロードセル$|カップリング$|モーター_0|モーター_2|ボス|ALU$/.test(n);
    const cast = /KP08（.）_0/.test(n);
    const acr = /^アクリル板（/.test(n);
    const smooth = /リード|ナット|カップリング|KP08|モーター軸|ボス|ねじ|ボルト|スペーサー|^配線/.test(n);
    o.material = new THREE.MeshStandardMaterial({ color: col, flatShading: !smooth,
      roughness: cast ? 0.55 : alu ? 0.42 : metal ? 0.32 : 0.6, metalness: cast ? 0.45 : alu ? 0.35 : metal ? 0.75 : 0.0,
      transparent: acr, opacity: acr ? 0.28 : 1, depthWrite: !acr });
    o.userData.baseOpacity = acr ? 0.28 : 1; o.userData.baseTransparent = acr;
    if (smooth) o.geometry.computeVertexNormals();
    if (!/リード|Arduino（|^配線/.test(n)) {
      const e = new THREE.LineSegments(new THREE.EdgesGeometry(o.geometry, 25), new THREE.LineBasicMaterial({ color: 0x3a4450, transparent: true, opacity: 0.35 }));
      e.userData.isEdge = true; o.add(e);
    }
    addToGroup(o, groupOf(n));
    if (/^(スライダー$|ナット|ロードセル$|部品B$|部品A$|ボルト_ロードセル)/.test(n)) movers.push(o);
    if (/^(リードスクリュー$|カップリング|モーター軸$)/.test(n)) rotors.push(o);
    if (n === "曲げ治具（枠）") jigFrame.push(o);
    if (n === "圧子") jigInd.push(o);
  }
  scene.add(g.scene);
  // 試験片（たわむように細かく分けた2つの半分）
  const [sx, sy, sz] = META.spec;
  const sm = new THREE.MeshStandardMaterial({ color: new THREE.Color().setRGB(150 / 255, 190 / 255, 235 / 255, THREE.SRGBColorSpace), roughness: 0.55 });
  for (const side of [-1, 1]) {
    const geo = new THREE.BoxGeometry(40, 10, 4, 40, 1, 2);
    geo.translate(side * 20, 0, 2);
    geo.userData.base = geo.attributes.position.array.slice();
    const m = new THREE.Mesh(geo, sm.clone()); m.castShadow = m.receiveShadow = true;
    m.position.set(sx, sy, sz); m.userData.side = side; m.userData.baseOpacity = 1; m.userData.baseTransparent = false;
    scene.add(m); specHalves.push(m); addToGroup(m, "specimen");
  }
  // ロードセルのケーブル（スライダーと一緒に動く）
  const cm = new THREE.MeshStandardMaterial({ color: 0x19191c, roughness: 0.6 });
  cableMesh = new THREE.Mesh(new THREE.BufferGeometry(), cm); cableMesh.castShadow = true;
  cableMesh.userData.baseOpacity = 1; cableMesh.userData.baseTransparent = false;
  scene.add(cableMesh); addToGroup(cableMesh, "wireL");
  // カメラ
  const cc = new THREE.Vector3(0, -40, 235);
  const az = +(q.get("az") ?? -28) * Math.PI / 180, el = +(q.get("el") ?? 12) * Math.PI / 180, d = +(q.get("d") || 1550);
  if (q.get("tz")) cc.set(+(q.get("tx") || 0), +(q.get("ty") || 0), +q.get("tz"));
  cam.position.set(cc.x + d * Math.cos(el) * Math.sin(az), cc.y - d * Math.cos(el) * Math.cos(az), cc.z + d * Math.sin(el));
  ctl = new OrbitControls(cam, renderer.domElement); ctl.target.copy(cc); ctl.enableDamping = true; ctl.update();
  buildPanel();
  for (const [k, v] of (q.get("set") || "").split(",").filter(Boolean).map((t) => t.split(":"))) setState(k, v);
  applyJig(); updateScene(true);
  resize();
  requestAnimationFrame(loop);
  window.ready = true;
}, (err) => { view.textContent = "3Dモデルを読み込めませんでした：" + err; }))
  .catch((err) => { view.textContent = "3Dモデルを読み込めませんでした：" + err; });

function setState(k, st) {
  const G = groups[k]; if (!G) return; G.state = st;
  for (const o of G.meshes) {
    const m = o.material;
    if (st === "ghost") { m.transparent = true; m.opacity = Math.min(0.16, o.userData.baseOpacity); m.depthWrite = false; o.castShadow = false; }
    else { m.transparent = o.userData.baseTransparent; m.opacity = o.userData.baseOpacity; m.depthWrite = !o.userData.baseTransparent; o.castShadow = true; }
    m.needsUpdate = true;
    for (const ch of o.children) if (ch.userData.isEdge) ch.material.opacity = st === "ghost" ? 0.12 : 0.35;
  }
  const row = document.querySelector(`[data-g="${k}"]`);
  if (row) row.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.s === st));
  applyJig();
}
function visibleOf(o) {
  const st = groups[o.userData.group]?.state;
  const isJig = jigFrame.includes(o) || jigInd.includes(o) || specHalves.includes(o);
  return st !== "hidden" && (!isJig || jig.attached || jig.anim < 1);
}
function applyJig() { for (const k in groups) for (const o of groups[k].meshes) o.visible = visibleOf(o); }
function select(k) {
  if (selected && groups[selected]) for (const o of groups[selected].meshes) o.material.emissive?.setHex(0x000000);
  selected = k;
  const info = $("#info");
  if (!k || !groups[k]) { info.hidden = true; return; }
  for (const o of groups[k].meshes) o.material.emissive.setHex(0x1f4e9a), o.material.emissiveIntensity = 0.35;
  const gg = GROUPS.find((x) => x[0] === k);
  info.hidden = false; info.querySelector("h3").textContent = gg ? gg[2] : k; info.querySelector("p").textContent = gg ? gg[3] : "";
  document.querySelectorAll(".row").forEach((r) => r.classList.toggle("sel", r.dataset.g === k));
}
function buildPanel() {
  const list = $("#list");
  for (const [k, , label] of GROUPS) {
    if (!groups[k]) continue;
    const r = document.createElement("div"); r.className = "row"; r.dataset.g = k;
    r.innerHTML = `<span class="nm">${label}</span><span class="seg"><button data-s="normal" class="on">表示</button><button data-s="ghost">半透明</button><button data-s="hidden">非表示</button></span>`;
    r.querySelector(".nm").onclick = () => select(k);
    r.querySelectorAll("button").forEach((b) => b.onclick = () => setState(k, b.dataset.s));
    list.appendChild(r);
  }
  $("#allNormal").onclick = () => Object.keys(groups).forEach((k) => setState(k, "normal"));
  $("#seeInside").onclick = () => ["base", "table", "acryl", "slider", "top", "duct"].forEach((k) => setState(k, "ghost"));
  $("#info .close").onclick = () => select(null);
  $("#info .ghost").onclick = () => selected && setState(selected, groups[selected].state === "ghost" ? "normal" : "ghost");
  $("#info .hide").onclick = () => selected && setState(selected, "hidden");
}
const ray = new THREE.Raycaster(); let down = null;
renderer.domElement.addEventListener("pointerdown", (e) => down = [e.clientX, e.clientY]);
renderer.domElement.addEventListener("pointerup", (e) => {
  if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 5) return;
  const r = renderer.domElement.getBoundingClientRect();
  ray.setFromCamera(new THREE.Vector2((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1), cam);
  const hits = ray.intersectObjects(scene.children, true).filter((h) => h.object.isMesh && h.object.visible && h.object.userData.group && groups[h.object.userData.group].state !== "ghost");
  select(hits.length ? hits[0].object.userData.group : null);
});

// 試験片のたわみ（3点曲げのたわみ曲線。支点の外は持ち上がる）
function bendSpecimen() {
  const delta = jig.attached ? Math.max(0, -mech.H) : 0;
  for (const m of specHalves) {
    const geo = m.geometry, P = geo.attributes.position.array, B0 = geo.userData.base, side = m.userData.side;
    const broken = spec.broken;
    const db = broken ? spec.dBreak + 1.6 : Math.min(delta, spec.dc);
    for (let i = 0; i < P.length; i += 3) {
      const x = B0[i], s = Math.abs(x) / (SPAN_L / 2);
      let w;
      if (!broken) w = s <= 1 ? db * (1 - s) * (3 - (1 - s) ** 2) / 2 : -1.5 * db * (s - 1);
      else w = s <= 1 ? db * (1 - s) : -db * (s - 1);
      P[i] = x + (broken ? side * 0.5 : 0);
      P[i + 2] = B0[i + 2] - w;
    }
    geo.attributes.position.needsUpdate = true; geo.computeVertexNormals();
  }
}
// ケーブル
let cableH = null;
function updateCable() {
  if (cableH !== null && Math.abs(cableH - mech.H) < 0.4) return;
  cableH = mech.H;
  const C = META.cable.map((p) => new THREE.Vector3(...p));
  const H = mech.H;
  const a = [C[0], C[1], C[2]].map((p) => p.clone().add(new THREE.Vector3(0, 0, H)));
  const end = C[5];
  const mid = a[2].clone().lerp(end, 0.5).add(new THREE.Vector3(-30, -14, -Math.max(0, 40 - Math.abs(a[2].z - end.z) * 0.15)));
  const pts = [...a, mid, ...C.slice(5)];
  const curve = new THREE.CatmullRomCurve3(pts, false, "centripetal");
  cableMesh.geometry.dispose();
  cableMesh.geometry = new THREE.TubeGeometry(curve, 220, 2.0, 8, false);
}
function updateScene(force) {
  const H = mech.H;
  for (const o of movers) o.position.z = H;
  for (const o of rotors) o.rotation.z = -H / 2 * Math.PI * 2;
  // 治具の出し入れ（前から差し込む）
  let jy = 0;
  if (jig.anim < 1) { const t = Math.min(1, (performance.now() - jig.t0) / 700); jig.anim = t; const e = t * t * (3 - 2 * t); jy = jig.from + (jig.to - jig.from) * e; if (t >= 1) applyJig(); }
  else jy = jig.attached ? 0 : -260;
  for (const o of jigFrame) o.position.y = jy;
  for (const o of jigInd) { o.position.y = jy; o.position.z = H; }
  for (const m of specHalves) m.position.y = META.spec[1] + jy;
  bendSpecimen(); updateCable();
}

// =====================================================================
//  シミュレーター側の操作
// =====================================================================
function canHandleJig() { return ard.state === "IDLE" && mech.H >= 0; }
function toggleJig() {
  if (!canHandleJig()) {
    toast(ard.state !== "IDLE" ? "モーターが止まってから付け外ししてください。" : "圧子が試験片に当たる高さです。スライダーを上げてから付け外ししてください。");
    return;
  }
  jig.attached = !jig.attached; jig.from = jig.attached ? -260 : 0; jig.to = jig.attached ? 0 : -260; jig.anim = 0; jig.t0 = performance.now();
  applyJig(); refreshSimUi(); stepGuide();
}
function swapSpecimen() {
  if (jig.attached && mech.H < 0) { toast("圧子が試験片に当たっています。スライダーを上げてから交換してください。"); return; }
  newSpecimen(); refreshSimUi(); toast("新しい試験片をセットしました。");
}
function refreshSimUi() {
  $("#bJig").textContent = jig.attached ? "曲げ治具を外す" : "曲げ治具を取り付ける";
  $("#bJig").classList.toggle("pri", !jig.attached && pc.sys === "WAIT_TEST");
  $("#bSpec").disabled = !jig.attached;
}
let toastTimer = 0;
function toast(t, warn) {
  const el = $("#toast"); el.textContent = t; el.hidden = false; el.classList.toggle("warn", !!warn);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.hidden = true, warn ? 9000 : 4200);
}
const STEPS = [
  ["IDLE", "曲げ治具を外した状態で、UP（↑）・DOWN（↓）でモーターが動くか確かめる"],
  ["FAST_DOWN", "START（Enter）で高速降下（8 mm/s）"],
  ["SLOW_DOWN", "台に着く少し手前（左上のすき間が 10〜20 mm）で 0mm homing（0 キー）→ 低速（0.5 mm/s）"],
  ["HOME", "部品Aが試験台に当たって 0.5 N を検知 → 137 mm 上昇"],
  ["WAIT_TEST", "曲げ治具と試験片をセットし、試験片名を入力して START → 保存先を選ぶ"],
  ["TESTING", "試験（2 mm/min）→ 破断を検知 → 試験開始点まで戻る → 保存"],
];
function stepGuide() {
  let cur = 0;
  const s = pc.sys;
  if (s === "FAST_DOWN") cur = 1; else if (s === "SLOW_DOWN") cur = seq.phase === "detect" ? 2 : 3;
  else if (s === "WAIT_TEST") cur = 4; else if (s === "TESTING" || s === "SAVING") cur = 5; else if (s === "FINISHED") cur = 4;
  if (seq.active && seq.phase !== "detect") cur = 3;
  const ol = $("#steps");
  ol.innerHTML = STEPS.map(([, t], i) => `<li class="${i === cur ? "cur" : i < cur ? "done" : ""}"><b>${i + 1}</b><span>${t}</span></li>`).join("");
  refreshSimUi();
}
function status3d() {
  const gapA = mech.H - H_CONTACT;
  let t;
  if (jig.attached) {
    const d = -mech.H;
    t = d <= 0 ? `圧子と試験片のすき間 ${(-d).toFixed(2)} mm` : spec.broken ? "試験片：破断" : `たわみ ${d.toFixed(2)} mm`;
  } else t = `部品Aと試験台のすき間 ${Math.max(0, gapA).toFixed(1)} mm`;
  const mv = ard.state === "IDLE" ? "停止" : { MOVING: ard.up ? "上昇" : "下降", HOMING: "137 mm 上昇中", TESTING: "試験（下降）", RETURNING: "試験開始点へ戻り中" }[ard.state] || ard.state;
  $("#stat").innerHTML = `<span>${t}</span><span>モーター：${mv}${mech.stall && ard.state !== "IDLE" ? "（脱調）" : ""}</span><span>荷重（デモ値）${loadAt(mech.H).toFixed(2)} N</span>`;
  // 高速のまま衝突したときの注意
}

// 保存したファイルの一覧
function renderFiles(dir, maxF, maxS, em) {
  const box = $("#files");
  box.hidden = false;
  box.innerHTML = `<div class="fh">保存されたファイル <small>${dir}</small></div><div class="fr">最大荷重 ${maxF.toFixed(3)} N ／ 最大曲げ応力 ${maxS.toFixed(2)} MPa ／ 弾性率 ${Number.isNaN(em) ? "nan" : em.toFixed(1)} MPa（デモ値）</div>` +
    `<div class="fimgs">${pc.files.filter((f) => f.url).map((f) => `<figure><img src="${f.url}" alt="${f.name}"><figcaption>${f.name}</figcaption></figure>`).join("")}</div>` +
    `<div class="fnote">グラフは右クリック（スマホは長押し）で画像として保存できます。</div>` +
    pc.files.filter((f) => f.text).map((f) => `<details class="fcsv"><summary>${f.name}（中身を表示）</summary><textarea id="csvText" readonly spellcheck="false"></textarea><button class="hb" id="csvCopy">CSV をコピー</button><span id="csvMsg"></span></details>`).join("");
  // パソコン用・GitHub Pages 用では、本物と同じようにファイルを保存できる（ダウンロードフォルダへ）
  if (ALLOW_DL) {
    const csvF = pc.files.find((x) => x.text);
    if (csvF && !csvF.url) csvF.dl = URL.createObjectURL(new Blob(["\ufeff" + csvF.text], { type: "text/csv" }));
    box.insertAdjacentHTML("beforeend", `<div class="fdl">${pc.files.map((x) => `<a class="hb" download="${x.name}" href="${x.url || x.dl}">⬇ ${x.name}</a>`).join("")}</div>`);
  }
  const f = pc.files.find((x) => x.text);
  if (f) {
    $("#csvText").value = f.text;
    $("#csvCopy").onclick = () => {
      const done = () => $("#csvMsg").textContent = "コピーしました。表計算ソフトに貼り付けてください。";
      const fallback = () => { $("#csvText").focus(); $("#csvText").select(); $("#csvMsg").textContent = "全体を選択しました。コピーしてください。"; };
      try { navigator.clipboard.writeText(f.text).then(done, fallback); } catch (e) { fallback(); }
    };
  }
}

// =====================================================================
//  メインループ
// =====================================================================
let lastFrame = performance.now(), lastGraphDraw = 0, lastStat = 0;
function simStep(dtTotal) {
  const DT = 0.005;
  let n = Math.ceil(dtTotal / DT);
  const dt = dtTotal / Math.max(n, 1);
  for (let i = 0; i < n; i++) {
    simT += dt;
    ardTick(dt); safetyTick(); sensorTick(); motorSearchTick(); seqTick(); uiTick();
  }
}
// シミュレーターの安全停止：0 キーで低速にする前に当たると、その荷重がゼロ点にされて試験が正しく測れなくなるため
function safetyTick() {
  const F = loadAt(mech.H);
  const downManual = ["IDLE", "FINISHED"].includes(pc.sys) && ard.state === "MOVING" && !ard.up;
  let why = "";
  if (pc.sys === "FAST_DOWN" && F > 3) why = "高速降下のまま試験台（または試験片）に当たりました";
  else if (downManual && F > 3) why = "DOWN で試験台（または試験片）に当たりました";
  else if (pc.sys === "SLOW_DOWN" && F > 20) why = "接触を検知できないまま押し込んでいます";
  if (why) safetyStop(why);
}
function safetyStop(why) {
  seq.active = false; seq.zeroF = 0;
  sendM("STOP");
  changeState("IDLE", "緊急停止しました。機械の状態を確認してください。");
  toast(`⚠ ${why}。シミュレーターが EMG STOP を押しました（実機では故障の原因になります）。UP（↑）で少し上げてから、もう一度 START → 台に着く手前で 0 キーを押してください。`, true);
}
let lastPhase = "";
function loop(now) {
  const real = Math.min((now - lastFrame) / 1000, 0.1); lastFrame = now;
  simStep(real * speed);
  updateScene();
  const ph = pc.sys + seq.phase + seq.active;
  if (ph !== lastPhase) { lastPhase = ph; stepGuide(); }
  if (now - lastStat > 100) { lastStat = now; status3d(); }
  if (graphDirty && now - lastGraphDraw > 90) { graphDirty = false; lastGraphDraw = now; renderGraph(); }
  ctl.update(); renderer.render(scene, cam);
  requestAnimationFrame(loop);
}

// =====================================================================
//  画面の大きさ
// =====================================================================
let winScale = 1;
function resize() {
  const r = view.getBoundingClientRect();
  renderer.setSize(r.width, r.height); cam.aspect = r.width / r.height; cam.updateProjectionMatrix();
  const host = $("#appHost"), win = $("#win");
  const hr = host.getBoundingClientRect();
  const narrow = window.matchMedia("(max-width: 900px)").matches;
  const pane = $("#paneApp").getBoundingClientRect();
  winScale = narrow ? hr.width / 1280 : Math.max(0.3, Math.min(hr.width / 1280, (pane.height - 34 - $("#stepsBox").getBoundingClientRect().height) / 852));
  win.style.transform = `scale(${winScale})`;
  win.style.left = `${Math.max(0, (hr.width - 1280 * winScale) / 2)}px`;
  host.style.setProperty("--wh", `${852 * winScale}px`);
  graphDirty = true;
}
{
  // ResizeObserver の中で直接サイズを変えると「ループ」エラーになるので、次のフレームでまとめて処理する
  let pend = false, last = "";
  const ro = new ResizeObserver(() => {
    if (pend) return; pend = true;
    requestAnimationFrame(() => {
      pend = false;
      const r = view.getBoundingClientRect(), b = $("#below").getBoundingClientRect();
      const key = [r.width, r.height, b.height, window.innerWidth, window.innerHeight, document.body.className].join(",");
      if (key !== last) { last = key; resize(); }
    });
  });
  ro.observe(document.body); ro.observe($("#below")); ro.observe(view);
}

// 起動（TesterApp.__init__ と同じ順番）
buildApp();
changeState("IDLE", "準備完了。Enterキーで開始。↑↓キーで手動操作。");
autoConnectMotor();
$("#bJig").onclick = toggleJig;
$("#bSpec").onclick = swapSpecimen;
document.querySelectorAll("#spd button").forEach((b) => {
  b.classList.toggle("on", +b.dataset.v === speed);
  b.onclick = () => { speed = +b.dataset.v; document.querySelectorAll("#spd button").forEach((x) => x.classList.toggle("on", x === b)); };
});
$("#bReset").onclick = () => location.reload();
$("#bParts").onclick = () => document.body.classList.toggle("parts");
function setMode(viewOnly) {
  document.body.classList.toggle("viewonly", viewOnly);
  if (viewOnly) document.body.classList.add("parts");
  $("#bMode").textContent = viewOnly ? "シミュレーションを開く" : "見るだけモード";
  $("#bMode").classList.toggle("pri", viewOnly);
  setTimeout(resize, 0);
}
$("#bMode").onclick = () => setMode(!document.body.classList.contains("viewonly"));
setMode(q.get("mode") === "view");
stepGuide();
window.SIM = { pc, ard, mech, jig, spec, get t() { return simT; }, setSpeed: (v) => speed = v, toggleJig };
