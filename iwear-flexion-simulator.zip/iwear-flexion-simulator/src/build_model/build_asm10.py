# 曲げ試験装置の組み立て（第10版）：配線を「配線カバー」と台の専用穴だけに通す（部品の貫通なし）
import os
_d = os.path.dirname(os.path.abspath(__file__))
_src = open(f"{_d}/asm10_head.py", encoding="utf-8").read() + open(f"{_d}/asm10_tail.py", encoding="utf-8").read()
exec(compile(_src, "build_asm10", "exec"))
