UL, UR, MD = MATS["左・モーター制御用"], MATS["右・ロードセル用"], MATS["DRV8825基板（モータードライバ）"]
D_PIN = {2: 57.98, 3: 55.44, 4: 52.90}; D_Y = 50.83
P_PIN = {"5V": 38.10, "GND": 40.64}; P_Y = 1.82
WIRES = {}


def wire(name, color, pts, r=0.9):
    m = tube(pts, r); put(name, m, "W" + color); WIRES[name] = (m, r)


def dupont(name, M, x, y, z0, L=14.0):
    """ジャンパーワイヤーの先（黒い樹脂のハウジング 2.4□×L）を、基板の局所座標 (x, y) のピンに法線方向へ z0〜z0+L で差す。
    返り値：配線の始点（ハウジングの外側の端）と、外へ向かう方向"""
    h = B(2.4, 2.4, L, x, y, z0); h.apply_transform(M); put(name, h, "HDR")
    tip = wp(M, x, y, z0 + L + 0.3); nrm = wp(M, x, y, z0 + L + 6.3) - tip
    return tip, nrm


# ---------------- 配線カバー（白いモール）と、台の専用穴 ----------------
# 台の専用穴（STL実測）：モーターの入る空洞（x −21〜21、y −25〜25）の後ろから台の背面（y=40）まで、x −10〜10、z 26.5〜35 の横穴
HOLE = dict(x0=-10.0, x1=10.0, z0=z_base + 11.5, z1=z_base + 20.0)
DUCT_W, DUCT_H, DUCT_T = 11.0, 15.0, 1.2


def duct_x(x0, x1, y_face, z0, outward):
    yc = y_face + outward * DUCT_W / 2
    outer = B(x1 - x0, DUCT_W, DUCT_H, (x0 + x1) / 2, yc, z0)
    inner = B(x1 - x0 + 2, DUCT_W - 2 * DUCT_T, DUCT_H - 2 * DUCT_T, (x0 + x1) / 2, yc, z0 + DUCT_T)
    return outer.difference(inner)


def duct_y(y0, y1, x_face, z0, outward):
    xc = x_face + outward * DUCT_W / 2
    outer = B(DUCT_W, y1 - y0, DUCT_H, xc, (y0 + y1) / 2, z0)
    inner = B(DUCT_W - 2 * DUCT_T, y1 - y0 + 2, DUCT_H - 2 * DUCT_T, xc, (y0 + y1) / 2, z0 + DUCT_T)
    return outer.difference(inner)


FRONT_FACE, BACK_FACE = -140.5, 40.0
FD_Z0 = 4.0                                            # 前：台の中央の出っ張りの前面の下（x −65〜65）
put("配線カバー（前）", duct_x(-65.0, 65.0, FRONT_FACE, FD_Z0, -1), "WHT")
BD_Z0 = HOLE["z0"] - 3.5                               # 後ろ：専用穴にかぶせ、右の角で曲げて右側面へ
bd = duct_x(-14.0, SIDE_X + DUCT_W, BACK_FACE, BD_Z0, +1)
bd = bd.difference(B(DUCT_W - 2 * DUCT_T, DUCT_W, DUCT_H - 2 * DUCT_T, SIDE_X + DUCT_W / 2, BACK_FACE + DUCT_W / 2 - DUCT_T, BD_Z0 + DUCT_T))
bd = bd.difference(B(HOLE["x1"] - HOLE["x0"] - 2, 3, HOLE["z1"] - HOLE["z0"] - 1, 0, BACK_FACE + DUCT_T / 2, HOLE["z0"] + 0.5))
sd = duct_y(-24.0, BACK_FACE + DUCT_T, SIDE_X, BD_Z0, +1)
put("配線カバー（後ろ）", trimesh.boolean.union([bd, sd]), "WHT")
BD_ZC, FD_ZC = BD_Z0 + DUCT_H / 2, FD_Z0 + DUCT_H / 2

# ---------------- モーター → DRV8825（4本） ----------------
CON_Z = z_motor0 + 5.0
put("モーター_コネクタ", B(16, 3.4, 7, 0, 21.15 + 1.7, z_motor0 + 1.5), "WHT")
put("DRV8825基板（モータードライバ）_モーター用プラグ", B(12.5, 5.8, 4, 12, 15, 8.7).apply_transform(MD), "WHT")
for i, col in enumerate(("BL", "Y", "R", "LG")):
    dx = -4.5 + i * 3.0
    a = np.array([dx, 21.15 + 3.4 + 0.6, CON_Z])
    zz = BD_ZC - 1.6 + (i % 2) * 3.2
    yy = BACK_FACE + 3.4 + (i // 2) * 3.4
    xx = SIDE_X + 3.4 + (i // 2) * 3.4
    b = wp(MD, 8.0 + i * 2.6, 15, 13.0)
    pts = [a, [dx, 32, CON_Z], [dx, BACK_FACE + 1.5, zz], [dx + 2, yy, zz], [xx - 2.5, yy, zz], [xx, yy - 2.5, zz], [xx, -26, zz], [xx, -32, zz + 4],
           [146 + i * 0.5, -34, 70], [146 + i * 0.5, b[1], b[2] + 6], b + [5, 0, 0], b]
    wire(f"配線M_モーター→DRV8825_{i}", col, pts, 0.8)

# ---------------- 前の配線カバーの中（下2段＝DRV8825→Arduino①、上＝HX711→Arduino②） ----------------
SL_Y = (-148.6, -146.0, -143.4); SL_Z = (FD_ZC - 3.3, FD_ZC, FD_ZC + 3.3)
SLOT_M = [(SL_Y[0], SL_Z[0]), (SL_Y[1], SL_Z[0]), (SL_Y[2], SL_Z[0]), (SL_Y[0], SL_Z[1]), (SL_Y[1], SL_Z[1])]
SLOT_L = [(SL_Y[2], SL_Z[1]), (SL_Y[0], SL_Z[2]), (SL_Y[1], SL_Z[2]), (SL_Y[2], SL_Z[2])]
drv_pins = [("STEP→D2", "R", (12.0, -16), ("D", 2)), ("DIR→D3", "O", (14.54, -16), ("D", 3)), ("EN→D4", "Y", (9.46, -16), ("D", 4)),
            ("5V", "G", (12.0, -18.6), ("P", "5V")), ("GND", "BL", (12.0, -21.2), ("P", "GND"))]


def ard_end(M, tag, lab, kind, pin):
    x, y = (D_PIN[pin], D_Y) if kind == "D" else (P_PIN[pin], P_Y)
    return dupont(f"配線_ジャンパー先（{tag}）{lab}", M, x, y, 10.0)


for i, (lab, col, (px, py), (kind, pin)) in enumerate(drv_pins):
    a, na = dupont(f"配線_ジャンパー先（DRV8825）{lab}", MD, px, py, 5.0)
    b, nb = ard_end(UL, "左", lab, kind, pin)
    sy, sz = SLOT_M[i]
    xr = 140.0 + i * 2.0                                   # 右側面の外（アクリル板の端 x=135.8 より外）を下ろす
    zf = 3.5 + i * 0.3
    pts = [a, a + na * 0.6 + [4, 0, 0], [xr + 6, a[1] - 3, a[2] - 10], [xr, -56, 30], [xr, -62, zf],
           [xr, -148 - i * 0.6, zf], [100, sy, zf], [72, sy, sz], [-70, sy, sz], [-74, sy, sz + 8]]
    if kind == "D":
        pts += [[b[0] + 3, -134, b[2] - 10], [b[0], b[1] + nb[1] * 1.5, b[2]], b]
    else:
        pts += [[-100, -146, 26], [b[0] + 2, -134, b[2] - 12], [b[0], b[1] + nb[1] * 1.5, b[2]], b]
    wire(f"配線M_DRV8825 {lab}", col, pts)

# ---------------- ロードセル → HX711（黒いケーブル） ----------------
lc_end = np.array([LC_X0 - 0.6, LCY, z_lc0 + LC_H / 2])
hx_in = HX_C + [-21.6, 0, 4.5]
wire("配線L_ロードセルのケーブル", "K", [lc_end, lc_end + [-10, 0, 0], [-100, -62, z_lc0 - 30], [-140, -95, 190], [-142, -105, 125],
                                     [-150, -125, 50], [-192, -148, 14], [-192, -168, 6], hx_in + [-6, 0, 0], hx_in], 2.0)

# ---------------- HX711 → Arduino②（右）：DATA→D3、SCK→D2、VCC→5V、GND ----------------
hx_pins = [("DATA→D3", "BL", ("D", 3)), ("SCK→D2", "Y", ("D", 2)), ("VCC→5V", "R", ("P", "5V")), ("GND", "G", ("P", "GND"))]
HXM = np.eye(4); HXM[:3, :3] = np.array([[0, 0, -1], [0, 1, 0], [1, 0, 0]], float).T   # 局所 z → 世界 +x（ピンが右向き）
HXM[:3, 3] = (HX_C[0] + 21.0, HX_C[1], 4.5)
for i, (lab, col, (kind, pin)) in enumerate(hx_pins):
    a, na = dupont(f"配線_ジャンパー先（HX711）{lab}", HXM, 0.0, -3.8 + i * 2.54, 2.6)
    b, nb = ard_end(UR, "右", lab, kind, pin)
    sy, sz = SLOT_L[i]
    pts = [a, a + [6, 0, 0], [-100, -158 + i * 1.5, 4], [-74, sy - 2, sz], [-66, sy, sz], [68, sy, sz], [74, sy - 1, sz + 10]]
    if kind == "D":
        pts += [[105, -146, 30], [b[0] - 2, -134, b[2] - 10], [b[0], b[1] + nb[1] * 1.5, b[2]], b]
    else:
        pts += [[b[0] - 2, -134, b[2] - 22], [b[0], b[1] + nb[1] * 1.5, b[2]], b]
    wire(f"配線L_HX711 {lab}", col, pts)

# ---------------- USB（2台とも USB ハブ経由で PC へ）・DRV8825 の電源 ----------------
HUB = np.array([-15.0, -215.0, 0.0])
put("USBハブ", B(105, 34, 16, HUB[0], HUB[1], 0.0), "BLACK")
for k, (tag, M) in enumerate((("左", UL), ("右", UR))):
    u = wp(M, -6.0, 37.0, 7.0)
    put(f"USBプラグ（{tag}）", B(12.5, 11.5, 22, u[0], u[1], u[2] - 4), "WUSB")
    h = HUB + [-35 + k * 50, 0, 16]
    put(f"USBプラグA（{tag}）", B(13, 8, 20, h[0], h[1], 10), "WUSB")
    sgn = -1 if tag == "左" else 1
    wire(f"配線U_USB（{tag}）", "USB", [u + [0, 0, 18.5], u + [0, -6, 50], [u[0] - sgn * 10, -150, u[2] + 40], [h[0] + sgn * 20, -205, 95], [h[0], h[1], 60], h + [0, 0, 14.5]], 2.2)
wire("配線U_USBハブ→PC", "K", [HUB + [53, 0, 8], HUB + [70, 0, 6], HUB + [110, -30, 3], HUB + [190, -60, 3]], 2.0)
t = wp(MD, -14, 15, 12.2)
for i, col in enumerate(("R", "K")):
    a = t + [0, -1.5 + i * 3, 0]
    wire(f"配線U_DRV8825電源_{i}", col, [a, a + [10, 0, 6], a + [40, 30, -30], [a[0] + 70, 120, 3], [a[0] + 80, 200, 3]], 1.0)

if MODE == "cut":
    parts = {k: m for k, m in parts.items() if k not in ("台",)}

# ---------------- 貫通チェック：配線の表面の点が、どこかの部品の中に入っていないか ----------------
if "--check" in sys.argv:
    solids = {k: m for k, m in parts.items() if not k.startswith("配線") or k.startswith("配線カバー") or k.startswith("配線_ジャンパー")}
    bad = []
    for wn, (wm, r) in WIRES.items():
        P = wm.vertices
        for sn, sm in solids.items():
            lo, hi = sm.bounds
            sel = np.all((P > lo - 0.01) & (P < hi + 0.01), axis=1)
            if not sel.any(): continue
            Q = P[sel]
            if sm.is_watertight:
                inside = sm.contains(Q)
            else:
                cp, dist, tri = trimesh.proximity.closest_point(sm, Q)
                inside = ((Q - cp) * sm.face_normals[tri]).sum(1) < -1e-3
            n = int(inside.sum())
            if n: bad.append((wn, sn, n, np.round(Q[inside].mean(0), 1).tolist()))
    for b_ in bad: print("HIT", *b_)
    print("hits:", len(bad))

CABLE_PTS = [lc_end, lc_end + [-10, 0, 0], [-100, -62, z_lc0 - 30], [-140, -95, 190], [-142, -105, 125],
             [-150, -125, 50], [-192, -148, 14], [-192, -168, 6], hx_in + [-6, 0, 0], hx_in]
META = dict(z_table=float(z_table1), spec=[float(AX), float(b_mid_y), float(z_table1 + 40.0)],
            cable=[[float(v) for v in p] for p in CABLE_PTS], z_b0=float(z_b0))
json.dump(META, open(OUT.replace(".glb", ".meta.json"), "w"))
scene = trimesh.Scene()
for k, m in parts.items():
    scene.add_geometry(m, node_name=k, geom_name=k)
scene.export(OUT)
print("done", len(parts))
