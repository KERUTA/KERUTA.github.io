# 曲げ試験装置の組み立て（第4版）：写真に合わせて ロードセル位置・試験台（台のくぼみにはまる）・部品A（圧子をはめるT溝）・ナット位置を修正
# 座標：原点＝リードスクリューの軸の床面、x＝パイプの並ぶ向き、y−＝正面側、z＝上
import sys, json, trimesh, numpy as np
from trimesh.creation import box, cylinder
from trimesh.transformations import rotation_matrix as rot

IN, OUT = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "1"
WITH_JIG = MODE == "1"
C = dict(PLA=[242, 242, 236, 255], STEEL=[138, 144, 150, 255], SCREW=[176, 180, 186, 255], ALU=[205, 210, 215, 255],
         ZINC=[128, 132, 136, 255], BRASS=[200, 152, 58, 255], BLACK=[38, 40, 44, 255], RUBBER=[25, 25, 28, 255],
         SPEC=[150, 190, 235, 255], GREEN=[34, 74, 52, 255], PCB=[0, 98, 128, 255], HDR=[30, 30, 32, 255], CHIP=[24, 24, 26, 255], CAP=[60, 60, 70, 255], ACRYL=[200, 225, 240, 255], BOLT=[120, 124, 130, 255], BLKPCB=[28, 28, 30, 255], REDH=[200, 30, 35, 255], GRNT=[30, 150, 70, 255], WHT=[235, 235, 228, 255], PURP=[110, 70, 160, 255], HXG=[20, 120, 60, 255], YEL=[230, 200, 40, 255])
parts = {}


def put(name, mesh, color, T=(0, 0, 0)):
    m = mesh.copy(); m.apply_translation(T); m.visual.face_colors = C[color]; parts[name] = m
    return m


def B(sx, sy, sz, cx, cy, z0):
    b = box((sx, sy, sz)); b.apply_translation((cx, cy, z0 + sz / 2)); return b


def CYL(r, h, cx, cy, z0, axis="z", sec=72):
    c = cylinder(radius=r, height=h, sections=sec)
    if axis == "y": c.apply_transform(rot(np.pi / 2, (1, 0, 0)))
    if axis == "x": c.apply_transform(rot(np.pi / 2, (0, 1, 0)))
    c.apply_translation((cx, cy, z0 if axis != "z" else z0 + h / 2)); return c


ld = lambda f: trimesh.load(f"{IN}/{f}")


# ---------------- 台形ねじ Tr8×2（JIS B 0216 / DIN 103 の基準山形） ----------------
def tr_screw(L, z0, d=8.0, P=2.0, N=72):
    """おねじ：外径 d、ピッチ P（1条、リード=P）、山の角度 30°
    谷の径 d3 = d − 2·h3、h3 = 0.5P + ac（ac = 0.25 mm）→ Tr8×2 で d3 = 5.5 mm
    山頂の幅 = 0.366P、フランクの傾き 15°"""
    ac = 0.25
    h3 = 0.5 * P + ac
    R, r = d / 2, d / 2 - h3
    crest = 0.366 * P
    flank = h3 * np.tan(np.radians(15))
    # 1ピッチ内の断面（軸方向位置, 半径）
    prof = [(0.0, R), (crest, R), (crest + flank, r), (P - flank, r)]
    turns = int(np.ceil(L / P)) + 2
    K = turns * N
    th = np.arange(K + 1) * 2 * np.pi / N
    zz = z0 - P + th / (2 * np.pi) * P
    verts, faces = [], []
    rows = prof + [(P, R)]
    for i in range(4):            # 4本のらせん帯（山頂・下りフランク・谷・上りフランク）を別々の頂点で
        a, b_ = rows[i], rows[i + 1]
        base = len(verts) // 1
        for (s, rr) in (a, b_):
            z = np.clip(zz + s, z0, z0 + L)
            verts.append(np.c_[rr * np.cos(th), rr * np.sin(th), z])
        o0 = sum(len(v) for v in verts[:-2]); o1 = o0 + K + 1
        k = np.arange(K)
        faces.append(np.c_[o0 + k, o0 + k + 1, o1 + k + 1])
        faces.append(np.c_[o0 + k, o1 + k + 1, o1 + k])
    V = np.vstack(verts); F = np.vstack(faces)
    m = trimesh.Trimesh(V, F, process=False)
    caps = [CYL(R, 0.05, 0, 0, z0 - 0.02), CYL(R, 0.05, 0, 0, z0 + L - 0.03)]
    core = CYL(r + 0.01, L, 0, 0, z0, sec=48)
    return trimesh.util.concatenate([m, core] + caps)


# ---------------- 寸法 ----------------
PLATE_T, BASE_H = 15.0, 93.5
z_base, z_base_top = PLATE_T, PLATE_T + BASE_H
PIPE, PIPE_X = 25.0, 68.0
z_pipe0 = z_base + 11.0
# ステッピングモーター 17HS4401（42.3□×40、ボス Ø22×2、軸 Ø5×24 Dカット）を台の空洞の天井に下から固定
z_motor0 = z_base + 11.5                        # 台の下のすき間（157×106×11.5）に緑の板をはめ、その上にモーターを置く
z_motor_top = z_motor0 + 40.0
# リジッドカップリング 5×8（Ø20×25）
CPL_D, CPL_L = 20.0, 25.0
z_cpl0 = z_motor_top + 2.0 + 1.0
z_cpl1 = z_cpl0 + CPL_L
SCREW_L = 350.0
z_screw0 = z_cpl1 - 12.0
z_screw1 = z_screw0 + SCREW_L
# KP08（ピロー形フランジ軸受、内径8、取付穴ピッチ 36、全長 55、全高 13）
KP_L, KP_J, KP_H, KP_T = 55.0, 36.0, 13.0, 5.0
z_top = z_screw1                                # リードスクリューの上端を上の KP08 の上面（＝上部フレームの下面）にそろえる
TOP_H = 50.0
z_pipe1 = z_top + TOP_H
PIPE_L = z_pipe1 - z_pipe0
# 試験台（緑の板）：台の前側のくぼみ（台座標 x −150〜10、y −136.5〜−30、z 82〜93.5）にはまり、上面は台の上面と同じ高さ
TBL = dict(x0=-142 + 63.5, x1=15 + 63.5, y0=-136.5 - 4.0, y1=-30.5 - 4.0, z0=z_base + 82.3, z1=z_base_top)  # 台のくぼみ（STLの実寸）
z_table1 = TBL["z1"]
LC_L, LC_W, LC_H = 130.0, 30.0, 22.0            # ロードセル 130×30×22、M6×4（両端12 mm、幅方向15 mm）
LC_X0 = -67.0                                   # 固定側の M6 穴（端から12 mm）をスライダーの Ø6 穴（x=−37−18=−55）に合わせる
LCY = (-31.0 - 15.5) / 2 - 15.6                 # スライダーの Ø6 穴2つ（y=−31.0、−15.5、間隔15.5）の中心
IND_H = 153.0                                   # 曲げ治具 STL で、圧子の上面の高さ（試験片に当てた状態）
A_GAP = 3.0                                     # 部品Aの上面から、T溝の天井（＝圧子の上面）まで
z_b0 = z_table1 + IND_H + A_GAP                 # 部品Bの下面＝部品Aの上面
z_lc0 = z_b0 + 25.0
z_lc1 = z_lc0 + LC_H
Z_SLIDER = z_lc1 - 29.0                         # 張り出しの下の段（z=29）にロードセルの固定側
# ---------------- 3Dプリント部品（STL） ----------------
put("下板", ld("base_plate.stl"), "PLA", (-233.0, -8.5, 0))
put("台", ld("base.stl"), "PLA", (63.5, -4.0, z_base))
put("上部フレーム", ld("top_frame.stl"), "PLA", (47.0, -187.0, z_top))
put("スライダー", ld("slider.stl"), "PLA", (-18.0, -15.6, Z_SLIDER))
pb = ld("part_b.stl")
hole_x, hole_y = -24.5, (-109.0 - 124.5) / 2
tx, ty = (LC_X0 + 118.0) - hole_x, LCY - hole_y
put("部品B", pb, "PLA", (tx, ty, z_b0))
b_mid_x = tx + (-120.0 - 10.0) / 2
b_mid_y = ty + (-142.5 - 100.5) / 2
jig = ld("bending_jig.stl").split(only_watertight=False)
frame, ind = sorted(jig, key=lambda m: -m.volume)
icx, icy = (ind.bounds[0][0] + ind.bounds[1][0]) / 2, (ind.bounds[0][1] + ind.bounds[1][1]) / 2
AX = 0.0                                        # 部品A・圧子・治具は装置の中心（部品Bの真ん中あたり）
JT = (AX - icx, b_mid_y - icy, z_table1)
# 部品A：T溝（幅40×深さ5、首20×2）に圧子の頭がはまる。STL の z（45、z=0側が閉じている）を奥行き方向に、y を上下に
pa = ld("part_a.stl")
pa.apply_transform(rot(np.pi / 2, (1, 0, 0)))  # (x, y, z) → (x, −z, y)
# 回転後：x 50〜120、y −45〜0（0 が閉じた側＝奥）、z −139〜−119（上が −119）
put("部品A", pa, "PLA", (AX - 85.0, b_mid_y + 25.5, z_b0 + 119.0))
if WITH_JIG:
    put("曲げ治具（枠）", frame, "PLA", JT)
    put("圧子", ind, "PLA", JT)
    # 試験片 80×10×4：支点の上（治具の z=40〜44）
    put("試験片", B(80, 10, 4, AX, b_mid_y, z_table1 + 40.0), "SPEC")

# ---------------- 金属部品 ----------------
for i, sx in enumerate((-PIPE_X, PIPE_X)):
    p = B(PIPE, PIPE, PIPE_L, sx, 0, z_pipe0).difference(B(PIPE - 3.2, PIPE - 3.2, PIPE_L + 2, sx, 0, z_pipe0 - 1))
    put(f"角パイプ{i+1}", p, "STEEL")
put("リードスクリュー", tr_screw(SCREW_L, z_screw0), "SCREW")


def kp08(z0, up=True):
    """KP08：ダイカストのフランジ（ひし形）＋ハウジング＋608軸受（黒シール）＋止めねじ付きカラー"""
    fl = trimesh.convex.convex_hull(trimesh.util.concatenate([CYL(14, KP_T, 0, 0, 0), CYL(7.5, KP_T, -KP_J / 2, 0, 0), CYL(7.5, KP_T, KP_J / 2, 0, 0)]))
    hs = CYL(14, KP_H - 3, 0, 0, 0)
    body = fl.union(hs)
    for sx in (-KP_J / 2, KP_J / 2):
        body = body.difference(CYL(2.4, 20, sx, 0, -5))
    body = body.difference(CYL(11, 20, 0, 0, KP_H - 3 - 2.5)).difference(CYL(4.2, 40, 0, 0, -10))
    seal = CYL(11, 2.0, 0, 0, KP_H - 3 - 2.5).difference(CYL(6.5, 10, 0, 0, -5))
    collar = CYL(7, 6, 0, 0, KP_H - 6).difference(CYL(4.05, 20, 0, 0, KP_H - 10)).union(CYL(1.4, 3, 0, 0, 0, "x").apply_translation((7.5, 0, KP_H - 3)))
    ms = [(body, "ZINC"), (seal, "RUBBER"), (collar, "SCREW")]
    out = []
    for m, c in ms:
        m = m.copy()
        if not up:
            m.apply_transform(rot(np.pi, (1, 0, 0))); m.apply_translation((0, 0, KP_H))
        m.apply_translation((0, 0, z0)); out.append((m, c))
    return out


for tag, z0, up in (("下", z_base_top, True), ("上", z_top - KP_H, False)):
    for k, (m, c) in enumerate(kp08(z0, up)):
        put(f"KP08（{tag}）_{k}", m, c)
# 台形ねじ用ナット（T8 真ちゅう）：フランジ Ø22×3.5、胴 Ø10.2、全長15、取付穴 Ø3.5×4（PCD16）
zn = Z_SLIDER + 65.0                            # スライダー中央の橋（z 35〜65）の上面、V字の谷に付く
nut = CYL(11, 3.5, 0, 0, zn).union(CYL(5.1, 11.5, 0, 0, zn - 11.5)).union(CYL(5.1, 1.5, 0, 0, zn + 3.5))
for a in range(4):
    nut = nut.difference(CYL(1.75, 10, 8 * np.cos(np.pi / 4 + a * np.pi / 2), 8 * np.sin(np.pi / 4 + a * np.pi / 2), zn - 2))
nut = nut.difference(CYL(3.6, 40, 0, 0, zn - 20))
put("ナット", nut, "BRASS")
for a in range(4):   # 取付ねじ M3
    put(f"ナット取付ねじ{a}", CYL(2.6, 2.6, 8 * np.cos(np.pi / 4 + a * np.pi / 2), 8 * np.sin(np.pi / 4 + a * np.pi / 2), zn + 3.5, sec=24).difference(CYL(1.2, 3, 8 * np.cos(np.pi / 4 + a * np.pi / 2), 8 * np.sin(np.pi / 4 + a * np.pi / 2), zn + 4.6, sec=6)), "SCREW")
# リジッドカップリング（クランプ形）
cpl = CYL(CPL_D / 2, CPL_L, 0, 0, z_cpl0).difference(CYL(4, 40, 0, 0, z_cpl0 - 5))
cpl = cpl.difference(B(CPL_D + 2, 0.8, CPL_L + 2, 0, CPL_D / 4, z_cpl0 - 1))          # 縦のすり割り
cpl = cpl.difference(CYL(CPL_D / 2 + 1, 1.0, 0, 0, z_cpl0 + CPL_L / 2 - 0.5).difference(CYL(5, 3, 0, 0, z_cpl0 + CPL_L / 2 - 1.5)))
put("カップリング", cpl, "ALU")
for zz in (z_cpl0 + 6, z_cpl0 + CPL_L - 6):
    put(f"カップリングねじ{zz:.0f}", CYL(1.9, 3, 0, 0, 0, "x", sec=24).apply_translation((CPL_D / 2 - 1.5, CPL_D / 4 + 4, zz)), "BLACK")
# モーター 17HS4401
mot_cap = lambda z0, h: trimesh.convex.convex_hull(np.vstack([[(x, y, z) for x, y in
          [(21.15, 16.65), (16.65, 21.15), (-16.65, 21.15), (-21.15, 16.65), (-21.15, -16.65), (-16.65, -21.15), (16.65, -21.15), (21.15, -16.65)]] for z in (z0, z0 + h)]))
mot = [(mot_cap(z_motor0, 9), "ALU"), (mot_cap(z_motor0 + 9, 22).apply_scale(1.0), "BLACK"), (mot_cap(z_motor_top - 9, 9), "ALU")]
mot[1] = (trimesh.Trimesh(mot[1][0].vertices * [0.985, 0.985, 1], mot[1][0].faces), "BLACK")
for k, (m, c) in enumerate(mot):
    put(f"モーター_{k}", m, c)
put("モーター_ボス", CYL(11, 2, 0, 0, z_motor_top), "ALU")
shaft = CYL(2.5, 24, 0, 0, z_motor_top).difference(B(2, 10, 15, 3.5, 0, z_motor_top + 9.5))  # Dカット（4.5）
put("モーター軸", shaft, "SCREW")
# ロードセル
lc = B(LC_L, LC_W, LC_H, LC_X0 + LC_L / 2, LCY, z_lc0)
zc = z_lc0 + LC_H / 2
win = CYL(6.5, 40, LC_X0 + 42, LCY, 0, "y").union(CYL(6.5, 40, LC_X0 + 88, LCY, 0, "y")).union(B(46, 40, 5, LC_X0 + 65, LCY, -2.5))
win.apply_translation((0, 0, zc))
lc = lc.difference(win)
for hx in (LC_X0 + 12, LC_X0 + 118):
    for hy in (-7.75, 7.75):
        lc = lc.difference(CYL(3, 40, hx, LCY + hy, z_lc0 - 5))
put("ロードセル", lc, "ALU")

put("試験台", B(TBL["x1"] - TBL["x0"] - 0.4, TBL["y1"] - TBL["y0"] - 0.2, TBL["z1"] - TBL["z0"], (TBL["x0"] + TBL["x1"]) / 2, (TBL["y0"] + TBL["y1"]) / 2 - 0.15, TBL["z0"]), "GREEN")


put("試験台（下）", B(157 - 0.4, 106 - 0.2, 11.2, -63.5 + 63.5, (-62 + 44) / 2 - 4.0, z_base), "GREEN")   # 台の下のすき間（x −142〜15、y −62〜44、高さ 11.5）


# ---------------- ねじ・ボルト ----------------
def hexbolt(d, L, s_, k, z_head, up=True, cx=0.0, cy=0.0):
    """六角ボルト：頭（二面幅 s_、高さ k）の下面/上面を z_head に置き、軸を up=True なら下へ、False なら上へ伸ばす"""
    head = cylinder(radius=s_ / np.sqrt(3), height=k, sections=6)
    shank = cylinder(radius=d / 2 * 0.92, height=L, sections=20)
    if up:   # 頭が上、軸が下
        head.apply_translation((0, 0, z_head + k / 2)); shank.apply_translation((0, 0, z_head - L / 2))
    else:    # 頭が下、軸が上
        head.apply_translation((0, 0, z_head - k / 2)); shank.apply_translation((0, 0, z_head + L / 2))
    m = trimesh.util.concatenate([head, shank]); m.apply_translation((cx, cy, 0)); return m


def capscrew(d, L, z_head, up=True, cx=0.0, cy=0.0):
    """六角穴付きボルト（頭 Ø1.6d × d）"""
    D, k = 1.65 * d, d
    head = CYL(D / 2, k, 0, 0, 0, sec=28).difference(CYL(d * 0.45, k, 0, 0, k * 0.4, sec=6))
    shank = CYL(d / 2 * 0.92, L, 0, 0, -L, sec=20)
    m = trimesh.util.concatenate([head, shank])
    if not up:
        m.apply_transform(rot(np.pi, (1, 0, 0)))
    m.apply_translation((cx, cy, z_head)); return m


bolts = []
for sx in (-KP_J / 2, KP_J / 2):
    bolts.append(("KP08（下）固定ボルト M5", hexbolt(5, 25, 8, 3.5, z_base_top + KP_T, True, sx, 0)))
    bolts.append(("KP08（上）固定ボルト M5", hexbolt(5, 35, 8, 3.5, z_top - KP_T, False, sx, 0)))
for hy in (-7.75, 7.75):
    bolts.append(("ロードセル固定側ボルト M6", hexbolt(6, 40, 10, 4, Z_SLIDER + 49.0, True, LC_X0 + 12, LCY + hy)))
    bolts.append(("ロードセル可動側ボルト M6", hexbolt(6, 45, 10, 4, z_b0, False, LC_X0 + 118, LCY + hy)))
for i, (nm, m) in enumerate(bolts):
    put(f"ボルト_{nm}_{i}", m, "BOLT")

# ---------------- Arduino Uno Rev3（配布された VRML モデル）＋アクリル板 ----------------
UNO_MESH = trimesh.load(sys.argv[4] if len(sys.argv) > 4 else "parts/uno_raw.ply")


def uno_colored():
    m = UNO_MESH; c = m.triangles_center; x, y, z = c[:, 0], c[:, 1], c[:, 2]
    lab = np.full(len(c), "CHIP", dtype=object)
    lab[z < 2.02] = "PCB"
    lab[(z >= 2.02) & (x < 11) & (y > 29) & (y < 45)] = "ALU"                      # USB-B
    lab[(z >= 2.02) & (((x - 18) ** 2 + (y - 9) ** 2 < 9) | ((x - 24.5) ** 2 + (y - 9) ** 2 < 9))] = "ALU"  # 電解コンデンサ
    lab[(z >= 2.02) & ((y < 4) | (y > 48.5)) & (x > 16)] = "HDR"                   # ピンヘッダ
    out = []
    for L in ("PCB", "ALU", "HDR", "CHIP"):
        idx = np.where(lab == L)[0]
        if len(idx): out.append((m.submesh([idx], append=True), L))
    return out


UNO_HOLES = [(13.86, 2.51), (15.11, 50.52), (64.02, 7.5), (64.02, 35.34)]           # VRML モデル上の取付穴（x：長さ方向、y：幅方向）


MATS = {}


def place_uno(tag, center_x, face_y, z_usb_top):
    """台の前面（y=face_y）にアクリル板（3 mm）を当て、その前に M3 スペーサー 6 mm で Uno を縦に付ける。
    USB と電源ジャックが上、部品は手前向き（写真どおり）"""
    R = np.array([[0, 0, -1], [1, 0, 0], [0, -1, 0]], float).T   # 列：board x→−z、y→+x、z→−y
    ACR_T, SP = 3.0, 6.0
    origin = np.array([center_x - 26.5, face_y - ACR_T - SP, z_usb_top - 6.0])   # board (x=−6) が USB の上端
    M = np.eye(4); M[:3, :3] = R; M[:3, 3] = origin
    MATS[tag] = M
    for k, (m, c) in enumerate(uno_colored()):
        mm = m.copy(); mm.apply_transform(M); put(f"Arduino（{tag}）_{k}_{c}", mm, c)
    zc = z_usb_top - 40.0
    acr = B(64, ACR_T, 92, center_x, face_y - ACR_T / 2, zc - 46)
    for ax_, az_ in ((-27, -40), (27, -40), (-27, 40), (27, 40)):
        acr = acr.difference(CYL(1.7, 10, center_x + ax_, face_y, zc + az_, "y", sec=16))
        put(f"アクリル板ねじ（{tag}）{ax_}{az_}", capscrew(3, 10, 0, True).apply_transform(rot(-np.pi / 2, (1, 0, 0))).apply_translation((center_x + ax_, face_y - ACR_T, zc + az_)), "BOLT")
    put(f"アクリル板（{tag}）", acr, "ACRYL")
    for hx, hy in UNO_HOLES:
        p = M @ np.array([hx, hy, 0, 1])
        put(f"Arduinoスペーサー（{tag}）{hx}", CYL(2.6, SP, 0, 0, 0, "y", sec=6).apply_translation((p[0], face_y - ACR_T - SP / 2 + SP / 2, p[2])), "ALU")
        put(f"Arduinoねじ（{tag}）{hx}", capscrew(3, 6, 0, True).apply_transform(rot(-np.pi / 2, (1, 0, 0))).apply_translation((p[0], face_y - ACR_T - SP - 1.6, p[2])), "BOLT")


FACE_Y = -76.5 - 4.0                                   # 台の左右の部分の前面
place_uno("右・ロードセル用", (15 + 61.5) / 2 + 63.5 + 2.0, FACE_Y, z_base + 88.0)
place_uno("左・モーター制御用", (-188.5 - 142) / 2 + 63.5 - 2.0, FACE_Y, z_base + 88.0)

# ---------------- DRV8825 拡張ボード（42×42）と HX711 モジュール ----------------
def side_place(meshes, tag, cy, cz, face_x):
    """基板の局所座標（x：横、y：縦、z：法線）を、台の右側面（x=face_x）に外向き（+x）で置く"""
    R = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]], float).T     # 列：x→+y、y→+z、z→+x
    M = np.eye(4); M[:3, :3] = R; M[:3, 3] = (face_x + 5.0, cy, cz)
    MATS[tag] = M
    for k, (m, c) in enumerate(meshes):
        mm = m.copy(); mm.apply_transform(M); put(f"{tag}_{k}_{c}", mm, c)
    for sx, sy in ((-17, -17), (17, -17), (-17, 17), (17, 17)) if "DRV" in tag else ((-14, -7), (14, -7)):
        p = M @ np.array([sx, sy, 0, 1])
        put(f"{tag}スペーサー{sx}{sy}", CYL(2.5, 5, 0, 0, 0, "x", sec=6).apply_translation((face_x + 2.5, p[1], p[2])), "ALU")


def drv_board():
    o = [(B(42, 42, 1.6, 0, 0, 0), "BLKPCB")]
    o += [(B(2.6, 20.3, 8.5, -6.4, 2, 1.6), "REDH"), (B(2.6, 20.3, 8.5, 6.4, 2, 1.6), "REDH")]   # DRV8825 用ソケット
    o += [(B(15.5, 20.3, 1.2, 0, 2, 10.1), "PURP"), (B(9, 9, 6, 0, 2, 11.3), "ALU")]           # DRV8825 本体＋ヒートシンク
    o += [(B(10, 7.6, 10, -14, 15, 1.6), "GRNT"), (B(12.5, 5.8, 7, 12, 15, 1.6), "WHT")]       # 電源端子・モーター端子
    o += [(B(5, 8, 3, -15, -2, 1.6), "HDR"), (CYL(3.2, 7, 14, -2, 1.6, sec=24), "ALU")]          # DIP スイッチ（MS1〜3）・コンデンサ
    o += [(B(7.6, 2.6, 2.5, 12, -16, 1.6), "YEL"), (B(7.6, 2.6, 2.5, 12, -18.6, 1.6), "REDH"), (B(7.6, 2.6, 2.5, 12, -21.2, 1.6), "HDR")]   # 信号（EN・STEP・DIR）／5V／GND
    for px in (9.46, 12.0, 14.54):
        for py in (-16, -18.6, -21.2):
            o.append((CYL(0.32, 8, px, py, 4.1, sec=8), "ALU"))
    return o


def hx_board():
    o = [(B(34, 20, 1.6, 0, 0, 0), "HXG"), (B(10, 6, 1.8, 2, 0, 1.6), "CHIP")]
    o += [(B(2.5, 15.2, 8.5, -15.5, 0, 1.6), "HDR"), (B(2.5, 10.2, 8.5, 15.5, 0, 1.6), "HDR")]
    return o


SIDE_X = 61.5 + 63.5                                   # 台の右側面
side_place(drv_board(), "DRV8825基板（モータードライバ）", -58.0, z_base + 68.0, SIDE_X)

# HX711：緑のテープで包み、ロードセルのケーブルの途中（台の左前の床）に置いている
HX_C = np.array([-152.0, -168.0, 0.0])               # 台の左前、机の上
hx = B(42, 26, 9, HX_C[0], HX_C[1], 0.0)
put("HX711（ロードセル用アンプ）_テープ", hx, "GRNT")
put("HX711（ロードセル用アンプ）_ピン", B(2.6, 10.2, 8.5, HX_C[0] + 21 + 1.3, HX_C[1], 0.2), "HDR")

# ---------------- 配線（システム図どおり） ----------------
from scipy.interpolate import CubicSpline


def fillet(pts, rad=7.0, step=1.0):
    """折れ線の角を2次ベジェで丸めて、細かい点列にする（スプラインのはみ出しが出ない）"""
    P = [np.asarray(p, float) for p in pts]
    out = [P[0]]
    for i in range(1, len(P) - 1):
        a, b, c = P[i - 1], P[i], P[i + 1]
        la, lc = np.linalg.norm(b - a), np.linalg.norm(c - b)
        d = min(rad, 0.45 * la, 0.45 * lc)
        p0, p2 = b + (a - b) / la * d, b + (c - b) / lc * d
        out.append(p0)
        for t in np.linspace(0, 1, 8)[1:-1]:
            out.append((1 - t) ** 2 * p0 + 2 * t * (1 - t) * b + t ** 2 * p2)
        out.append(p2)
    out.append(P[-1])
    Q = [out[0]]
    for p in out[1:]:
        L = np.linalg.norm(p - Q[-1])
        if L < 1e-6: continue
        k = int(np.ceil(L / step))
        seg0 = Q[-1]
        Q += [seg0 + (p - seg0) * t for t in np.linspace(0, 1, k + 1)[1:]]
    return np.array(Q)


def tube(pts, r=0.9, n=10, samples=12):
    C = fillet(pts)
    T = np.gradient(C, axis=0); T /= np.linalg.norm(T, axis=1)[:, None]
    up = np.array([0, 0, 1.0]) if abs(T[0][2]) < 0.9 else np.array([1.0, 0, 0])
    N = np.cross(T[0], up); N /= np.linalg.norm(N)
    V, F = [], []
    for i in range(len(C)):
        if i:
            N = N - T[i] * (N @ T[i]); N /= np.linalg.norm(N)
        Bn = np.cross(T[i], N)
        for k in range(n):
            a = 2 * np.pi * k / n
            V.append(C[i] + r * (np.cos(a) * N + np.sin(a) * Bn))
    for i in range(len(C) - 1):
        for k in range(n):
            a, b, c, d_ = i * n + k, i * n + (k + 1) % n, (i + 1) * n + k, (i + 1) * n + (k + 1) % n
            F += [(a, b, d_), (a, d_, c)]
    return trimesh.Trimesh(np.array(V), np.array(F), process=False)


WCOL = dict(R=[210, 40, 40, 255], O=[235, 130, 30, 255], Y=[235, 200, 40, 255], G=[20, 140, 110, 255], BL=[40, 80, 200, 255],
            K=[25, 25, 28, 255], W=[230, 230, 230, 255], LG=[60, 170, 80, 255], USB=[60, 120, 220, 255])
for k_, v_ in WCOL.items():
    C["W" + k_] = v_


def wire(name, color, pts, r=0.9):
    put(name, tube(pts, r), "W" + color)


def wp(M, x, y, z):            # 基板の局所座標 → 世界座標
    return (M @ np.array([x, y, z, 1.0]))[:3]


